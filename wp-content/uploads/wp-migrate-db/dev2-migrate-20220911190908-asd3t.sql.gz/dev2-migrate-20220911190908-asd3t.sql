# WordPress MySQL database migration
#
# Generated: Sunday 11. September 2022 19:09 UTC
# Hostname: localhost
# Database: `dev2`
# URL: //wp-valet.test
# Path: /Users/barnettj7/Sites/wp-valet
# Tables: wp_ak_params, wp_ak_profiles, wp_ak_stats, wp_ak_storage, wp_ak_users, wp_akeeba_common, wp_commentmeta, wp_comments, wp_import_detail_log, wp_import_log_detail, wp_import_postID, wp_links, wp_options, wp_postmeta, wp_posts, wp_smackcsv_file_events, wp_smackuci_events, wp_term_relationships, wp_term_taxonomy, wp_termmeta, wp_terms, wp_ultimate_csv_importer_acf_fields, wp_ultimate_csv_importer_mappingtemplate, wp_ultimate_csv_importer_media, wp_ultimate_csv_importer_shortcode_manager, wp_usermeta, wp_users, wp_yoast_indexable, wp_yoast_indexable_hierarchy, wp_yoast_migrations, wp_yoast_primary_term, wp_yoast_seo_links
# Table Prefix: wp_
# Post Types: revision, attachment, page, post
# Protocol: http
# Multisite: false
# Subsite Export: false
# --------------------------------------------------------

/*!40101 SET NAMES utf8mb4 */;

SET sql_mode='NO_AUTO_VALUE_ON_ZERO';



#
# Delete any existing table `wp_ak_params`
#

DROP TABLE IF EXISTS `wp_ak_params`;


#
# Table structure of table `wp_ak_params`
#

CREATE TABLE `wp_ak_params` (
  `tag` varchar(255) NOT NULL,
  `data` longtext,
  PRIMARY KEY (`tag`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;


#
# Data contents of table `wp_ak_params`
#
INSERT INTO `wp_ak_params` ( `tag`, `data`) VALUES
('update_version', '7.3.0.1') ;

#
# End of data contents of table `wp_ak_params`
# --------------------------------------------------------



#
# Delete any existing table `wp_ak_profiles`
#

DROP TABLE IF EXISTS `wp_ak_profiles`;


#
# Table structure of table `wp_ak_profiles`
#

CREATE TABLE `wp_ak_profiles` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `description` varchar(255) NOT NULL,
  `configuration` longtext,
  `filters` longtext,
  `quickicon` tinyint NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3;


#
# Data contents of table `wp_ak_profiles`
#
INSERT INTO `wp_ak_profiles` ( `id`, `description`, `configuration`, `filters`, `quickicon`) VALUES
(1, 'Default Backup Profile', '{"global":[],"akeeba":{"tuning":{"min_exec_time":"2000","max_exec_time":"14","run_time_bias":"75","nobreak":{"beforelargefile":"0","afterlargefile":"0","proactive":"0","domains":"0","finalization":"0"},"settimelimit":"0"},"advanced":{"autoresume":"1","autoresume_timeout":"10","autoresume_maxretries":"3","dump_engine":"native","scan_engine":"large","archiver_engine":"jpa","postproc_engine":"none","embedded_installer":"angie-wordpress","uploadkickstart":"0","integritycheck":"0"},"quota":{"remote":"0","maxage":{"enable":"0"},"obsolete_quota":"50","enable_size_quota":"0","size_quota":"15728640","enable_count_quota":"1","count_quota":"3"},"basic":{"output_directory":"\\/Applications\\/MAMP\\/htdocs\\/dev2\\/wp-content\\/plugins\\/akeebabackupwp\\/app\\/backups","log_level":"4","archive_name":"site-[HOST]-[DATE]-[TIME_TZ]-[RANDOM]","backup_type":"full","clientsidewait":"0"},"platform":{"scripttype":"wordpress"}},"engine":{"installer":{"angie":{"key":""}},"archiver":{"common":{"dereference_symlinks":"0","part_size":"0","chunk_size":"1048576","big_file_threshold":"1048576"},"zip":{"cd_glue_chunk_size":"1048576"}},"dump":{"divider":{"common":"0","mysql":"0"},"common":{"blankoutpass":"0","extended_inserts":"1","packet_size":"131072","splitsize":"524288","batchsize":"1000"},"native":{"advanced_entitites":"0","nodependencies":"0","nobtree":"1"}},"scan":{"large":{"dir_threshold":"100","file_threshold":"50"},"common":{"largefile":"10485760"},"smart":{"large_dir_threshold":"100"}}},"core":{"filters":{"hoststats":{"enabled":"1"},"dateconditional":{"enabled":"0","start":"1981-02-20 12:15 GMT+2"},"errorlogs":{"enabled":"1"}}}}', '', 1) ;

#
# End of data contents of table `wp_ak_profiles`
# --------------------------------------------------------



#
# Delete any existing table `wp_ak_stats`
#

DROP TABLE IF EXISTS `wp_ak_stats`;


#
# Table structure of table `wp_ak_stats`
#

CREATE TABLE `wp_ak_stats` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `description` varchar(255) NOT NULL,
  `comment` longtext,
  `backupstart` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `backupend` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `status` enum('run','fail','complete') NOT NULL DEFAULT 'run',
  `origin` varchar(30) NOT NULL DEFAULT 'backend',
  `type` varchar(30) NOT NULL DEFAULT 'full',
  `profile_id` bigint NOT NULL DEFAULT '1',
  `archivename` longtext,
  `absolute_path` longtext,
  `multipart` int NOT NULL DEFAULT '0',
  `tag` varchar(255) DEFAULT NULL,
  `backupid` varchar(255) DEFAULT NULL,
  `filesexist` tinyint NOT NULL DEFAULT '1',
  `remote_filename` varchar(1000) DEFAULT NULL,
  `total_size` bigint NOT NULL DEFAULT '0',
  `frozen` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_fullstatus` (`filesexist`,`status`),
  KEY `idx_stale` (`status`,`origin`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;


#
# Data contents of table `wp_ak_stats`
#

#
# End of data contents of table `wp_ak_stats`
# --------------------------------------------------------



#
# Delete any existing table `wp_ak_storage`
#

DROP TABLE IF EXISTS `wp_ak_storage`;


#
# Table structure of table `wp_ak_storage`
#

CREATE TABLE `wp_ak_storage` (
  `tag` varchar(255) NOT NULL,
  `lastupdate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `data` longtext,
  PRIMARY KEY (`tag`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;


#
# Data contents of table `wp_ak_storage`
#
INSERT INTO `wp_ak_storage` ( `tag`, `lastupdate`, `data`) VALUES
('liveupdate', '2022-04-13 09:28:25', '{"stuck":0,"software":"Akeeba Backup for WordPress","version":"7.6.3","link":"https:\\/\\/cdn.akeeba.com\\/downloads\\/backupwp\\/7.6.3\\/akeebabackupwp-7.6.3-core.zip","date":"2022-04-04","releasenotes":"","infourl":"https:\\/\\/www.akeeba.com\\/download\\/backupwp\\/7-6-3.html","md5":"f7c57e29da67b4b9850aa3c8a30bed99","sha1":"4b74be6ea4d0ff0e30e4e8ab9c791210780dbd47","sha256":"a1c7afb1a98045bd23f47778a718ce4fa6e6525ae0ba44a894007d7ac2eb0aca","sha384":"d0013667c59aba14844796e9637dae112de9e447de2fc882bc8a951e986a2fcaf56fca448c2e96714968e27ba809fd5c","sha512":"690bac87ec65f53247b2cd597ac47856696d39c3ad500244d2bb8599701e8c2b29f45b6ae43afb3ef82e24a816957435257cd5a8d2f0b1c0d1c3210911ffac87","platforms":"classicpress\\/1.0,wordpress\\/4.9+,wordpress\\/5.2+,php\\/7.2,php\\/7.3,php\\/7.4,php\\/8.0,php\\/8.1","loadedUpdate":1,"stability":"stable"}'),
('liveupdate_lastcheck', '2022-04-13 09:28:25', '1649867305') ;

#
# End of data contents of table `wp_ak_storage`
# --------------------------------------------------------



#
# Delete any existing table `wp_ak_users`
#

DROP TABLE IF EXISTS `wp_ak_users`;


#
# Table structure of table `wp_ak_users`
#

CREATE TABLE `wp_ak_users` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `parameters` longtext,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;


#
# Data contents of table `wp_ak_users`
#

#
# End of data contents of table `wp_ak_users`
# --------------------------------------------------------



#
# Delete any existing table `wp_akeeba_common`
#

DROP TABLE IF EXISTS `wp_akeeba_common`;


#
# Table structure of table `wp_akeeba_common`
#

CREATE TABLE `wp_akeeba_common` (
  `key` varchar(190) CHARACTER SET utf8mb3 COLLATE utf8_unicode_ci NOT NULL,
  `value` longtext NOT NULL,
  PRIMARY KEY (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;


#
# Data contents of table `wp_akeeba_common`
#

#
# End of data contents of table `wp_akeeba_common`
# --------------------------------------------------------



#
# Delete any existing table `wp_commentmeta`
#

DROP TABLE IF EXISTS `wp_commentmeta`;


#
# Table structure of table `wp_commentmeta`
#

CREATE TABLE `wp_commentmeta` (
  `meta_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `comment_id` bigint unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`meta_id`),
  KEY `comment_id` (`comment_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_commentmeta`
#

#
# End of data contents of table `wp_commentmeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_comments`
#

DROP TABLE IF EXISTS `wp_comments`;


#
# Table structure of table `wp_comments`
#

CREATE TABLE `wp_comments` (
  `comment_ID` bigint unsigned NOT NULL AUTO_INCREMENT,
  `comment_post_ID` bigint unsigned NOT NULL DEFAULT '0',
  `comment_author` tinytext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `comment_author_email` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_author_url` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_author_IP` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `comment_karma` int NOT NULL DEFAULT '0',
  `comment_approved` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '1',
  `comment_agent` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_type` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'comment',
  `comment_parent` bigint unsigned NOT NULL DEFAULT '0',
  `user_id` bigint unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`comment_ID`),
  KEY `comment_post_ID` (`comment_post_ID`),
  KEY `comment_approved_date_gmt` (`comment_approved`,`comment_date_gmt`),
  KEY `comment_date_gmt` (`comment_date_gmt`),
  KEY `comment_parent` (`comment_parent`),
  KEY `comment_author_email` (`comment_author_email`(10))
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_comments`
#
INSERT INTO `wp_comments` ( `comment_ID`, `comment_post_ID`, `comment_author`, `comment_author_email`, `comment_author_url`, `comment_author_IP`, `comment_date`, `comment_date_gmt`, `comment_content`, `comment_karma`, `comment_approved`, `comment_agent`, `comment_type`, `comment_parent`, `user_id`) VALUES
(1, 1, 'A WordPress Commenter', 'wapuu@wordpress.example', 'https://wordpress.org/', '', '2020-09-21 21:03:25', '2020-09-21 21:03:25', 'Hi, this is a comment.\nTo get started with moderating, editing, and deleting comments, please visit the Comments screen in the dashboard.\nCommenter avatars come from <a href="https://gravatar.com">Gravatar</a>.', 0, '1', '', 'comment', 0, 0),
(2, 6, 'A WordPress Commenter', 'wapuu@wordpress.example', 'https://wordpress.org/', '', '2020-09-01 22:46:18', '2020-09-01 22:46:18', 'Hi, this is a comment.\nTo get started with moderating, editing, and deleting comments, please visit the Comments screen in the dashboard.\nCommenter avatars come from <a href="https://gravatar.com" rel="nofollow ugc">Gravatar</a>.', 0, '1', '', 'comment', 0, 0) ;

#
# End of data contents of table `wp_comments`
# --------------------------------------------------------



#
# Delete any existing table `wp_import_detail_log`
#

DROP TABLE IF EXISTS `wp_import_detail_log`;


#
# Table structure of table `wp_import_detail_log`
#

CREATE TABLE `wp_import_detail_log` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `file_name` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL,
  `hash_key` varchar(255) NOT NULL,
  `total_records` int DEFAULT NULL,
  `processing_records` int DEFAULT '0',
  `remaining_records` int DEFAULT '0',
  `filesize` varchar(255) NOT NULL,
  `created` bigint NOT NULL DEFAULT '0',
  `updated` bigint NOT NULL DEFAULT '0',
  `skipped` bigint NOT NULL DEFAULT '0',
  `running` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;


#
# Data contents of table `wp_import_detail_log`
#

#
# End of data contents of table `wp_import_detail_log`
# --------------------------------------------------------



#
# Delete any existing table `wp_import_log_detail`
#

DROP TABLE IF EXISTS `wp_import_log_detail`;


#
# Table structure of table `wp_import_log_detail`
#

CREATE TABLE `wp_import_log_detail` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `hash_key` varchar(255) NOT NULL,
  `message` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL,
  `verify` blob NOT NULL,
  `categories` varchar(255) NOT NULL,
  `tags` varchar(255) NOT NULL,
  `post_id` int DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;


#
# Data contents of table `wp_import_log_detail`
#

#
# End of data contents of table `wp_import_log_detail`
# --------------------------------------------------------



#
# Delete any existing table `wp_import_postID`
#

DROP TABLE IF EXISTS `wp_import_postID`;


#
# Table structure of table `wp_import_postID`
#

CREATE TABLE `wp_import_postID` (
  `post_id` int NOT NULL,
  `line_number` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;


#
# Data contents of table `wp_import_postID`
#

#
# End of data contents of table `wp_import_postID`
# --------------------------------------------------------



#
# Delete any existing table `wp_links`
#

DROP TABLE IF EXISTS `wp_links`;


#
# Table structure of table `wp_links`
#

CREATE TABLE `wp_links` (
  `link_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `link_url` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_image` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_target` varchar(25) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_description` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_visible` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'Y',
  `link_owner` bigint unsigned NOT NULL DEFAULT '1',
  `link_rating` int NOT NULL DEFAULT '0',
  `link_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `link_rel` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_notes` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `link_rss` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`link_id`),
  KEY `link_visible` (`link_visible`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_links`
#

#
# End of data contents of table `wp_links`
# --------------------------------------------------------



#
# Delete any existing table `wp_options`
#

DROP TABLE IF EXISTS `wp_options`;


#
# Table structure of table `wp_options`
#

CREATE TABLE `wp_options` (
  `option_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `option_name` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `option_value` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `autoload` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'yes',
  PRIMARY KEY (`option_id`),
  UNIQUE KEY `option_name` (`option_name`),
  KEY `autoload` (`autoload`)
) ENGINE=InnoDB AUTO_INCREMENT=333 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_options`
#
INSERT INTO `wp_options` ( `option_id`, `option_name`, `option_value`, `autoload`) VALUES
(1, 'siteurl', 'http://wp-valet.test/', 'yes'),
(2, 'home', 'http://wp-valet.test/', 'yes'),
(3, 'blogname', 'NowRx New', 'yes'),
(4, 'blogdescription', 'Just another WordPress site', 'yes'),
(5, 'users_can_register', '0', 'yes'),
(6, 'admin_email', 'jeff.barnett@nowrx.com', 'yes'),
(7, 'start_of_week', '1', 'yes'),
(8, 'use_balanceTags', '0', 'yes'),
(9, 'use_smilies', '1', 'yes'),
(10, 'require_name_email', '1', 'yes'),
(11, 'comments_notify', '1', 'yes'),
(12, 'posts_per_rss', '10', 'yes'),
(13, 'rss_use_excerpt', '0', 'yes'),
(14, 'mailserver_url', 'mail.example.com', 'yes'),
(15, 'mailserver_login', 'login@example.com', 'yes'),
(16, 'mailserver_pass', 'password', 'yes'),
(17, 'mailserver_port', '110', 'yes'),
(18, 'default_category', '1', 'yes'),
(19, 'default_comment_status', 'open', 'yes'),
(20, 'default_ping_status', 'open', 'yes'),
(21, 'default_pingback_flag', '1', 'yes'),
(22, 'posts_per_page', '10', 'yes'),
(23, 'date_format', 'F j, Y', 'yes'),
(24, 'time_format', 'g:i a', 'yes'),
(25, 'links_updated_date_format', 'F j, Y g:i a', 'yes'),
(26, 'comment_moderation', '0', 'yes'),
(27, 'moderation_notify', '1', 'yes'),
(28, 'permalink_structure', '/%year%/%monthnum%/%day%/%postname%/', 'yes'),
(30, 'hack_file', '0', 'yes'),
(31, 'blog_charset', 'UTF-8', 'yes'),
(32, 'moderation_keys', '', 'no'),
(33, 'active_plugins', 'a:4:{i:0;s:34:"advanced-custom-fields-pro/acf.php";i:1;s:26:"nowrx-plugin/my-plugin.php";i:2;s:41:"wordpress-importer/wordpress-importer.php";i:3;s:31:"wp-migrate-db/wp-migrate-db.php";}', 'yes'),
(34, 'category_base', '', 'yes'),
(35, 'ping_sites', 'http://rpc.pingomatic.com/', 'yes'),
(36, 'comment_max_links', '2', 'yes'),
(37, 'gmt_offset', '0', 'yes'),
(38, 'default_email_category', '1', 'yes'),
(39, 'recently_edited', '', 'no'),
(40, 'template', 'nowrx', 'yes'),
(41, 'stylesheet', 'nowrx', 'yes'),
(42, 'comment_registration', '0', 'yes'),
(43, 'html_type', 'text/html', 'yes'),
(44, 'use_trackback', '0', 'yes'),
(45, 'default_role', 'subscriber', 'yes'),
(46, 'db_version', '53496', 'yes'),
(47, 'uploads_use_yearmonth_folders', '1', 'yes'),
(48, 'upload_path', '', 'yes'),
(49, 'blog_public', '1', 'yes'),
(50, 'default_link_category', '2', 'yes'),
(51, 'show_on_front', 'page', 'yes'),
(52, 'tag_base', '', 'yes'),
(53, 'show_avatars', '1', 'yes'),
(54, 'avatar_rating', 'G', 'yes'),
(55, 'upload_url_path', '', 'yes'),
(56, 'thumbnail_size_w', '150', 'yes'),
(57, 'thumbnail_size_h', '150', 'yes'),
(58, 'thumbnail_crop', '1', 'yes'),
(59, 'medium_size_w', '300', 'yes'),
(60, 'medium_size_h', '300', 'yes'),
(61, 'avatar_default', 'mystery', 'yes'),
(62, 'large_size_w', '1024', 'yes'),
(63, 'large_size_h', '1024', 'yes'),
(64, 'image_default_link_type', 'none', 'yes'),
(65, 'image_default_size', '', 'yes'),
(66, 'image_default_align', '', 'yes'),
(67, 'close_comments_for_old_posts', '0', 'yes'),
(68, 'close_comments_days_old', '14', 'yes'),
(69, 'thread_comments', '1', 'yes'),
(70, 'thread_comments_depth', '5', 'yes'),
(71, 'page_comments', '0', 'yes'),
(72, 'comments_per_page', '50', 'yes'),
(73, 'default_comments_page', 'newest', 'yes'),
(74, 'comment_order', 'asc', 'yes'),
(75, 'sticky_posts', 'a:0:{}', 'yes'),
(76, 'widget_categories', 'a:2:{i:2;a:4:{s:5:"title";s:0:"";s:5:"count";i:0;s:12:"hierarchical";i:0;s:8:"dropdown";i:0;}s:12:"_multiwidget";i:1;}', 'yes'),
(77, 'widget_text', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes'),
(78, 'widget_rss', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes'),
(79, 'uninstall_plugins', 'a:1:{s:33:"akeebabackupwp/akeebabackupwp.php";a:2:{i:0;s:14:"AkeebaBackupWP";i:1;s:9:"uninstall";}}', 'no'),
(80, 'timezone_string', '', 'yes'),
(81, 'page_for_posts', '11', 'yes'),
(82, 'page_on_front', '30', 'yes'),
(83, 'default_post_format', '0', 'yes'),
(84, 'link_manager_enabled', '0', 'yes'),
(85, 'finished_splitting_shared_terms', '1', 'yes'),
(86, 'site_icon', '0', 'yes'),
(87, 'medium_large_size_w', '768', 'yes'),
(88, 'medium_large_size_h', '0', 'yes'),
(89, 'wp_page_for_privacy_policy', '3', 'yes'),
(90, 'show_comments_cookies_opt_in', '1', 'yes'),
(91, 'admin_email_lifespan', '1678474852', 'yes'),
(92, 'disallowed_keys', '', 'no'),
(93, 'comment_previously_approved', '1', 'yes'),
(94, 'auto_plugin_theme_update_emails', 'a:0:{}', 'no'),
(95, 'initial_db_version', '48748', 'yes'),
(96, 'wp_user_roles', 'a:7:{s:13:"administrator";a:2:{s:4:"name";s:13:"Administrator";s:12:"capabilities";a:62:{s:13:"switch_themes";b:1;s:11:"edit_themes";b:1;s:16:"activate_plugins";b:1;s:12:"edit_plugins";b:1;s:10:"edit_users";b:1;s:10:"edit_files";b:1;s:14:"manage_options";b:1;s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:6:"import";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:8:"level_10";b:1;s:7:"level_9";b:1;s:7:"level_8";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;s:12:"delete_users";b:1;s:12:"create_users";b:1;s:17:"unfiltered_upload";b:1;s:14:"edit_dashboard";b:1;s:14:"update_plugins";b:1;s:14:"delete_plugins";b:1;s:15:"install_plugins";b:1;s:13:"update_themes";b:1;s:14:"install_themes";b:1;s:11:"update_core";b:1;s:10:"list_users";b:1;s:12:"remove_users";b:1;s:13:"promote_users";b:1;s:18:"edit_theme_options";b:1;s:13:"delete_themes";b:1;s:6:"export";b:1;s:20:"wpseo_manage_options";b:1;}}s:6:"editor";a:2:{s:4:"name";s:6:"Editor";s:12:"capabilities";a:35:{s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;s:15:"wpseo_bulk_edit";b:1;}}s:6:"author";a:2:{s:4:"name";s:6:"Author";s:12:"capabilities";a:10:{s:12:"upload_files";b:1;s:10:"edit_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:4:"read";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;s:22:"delete_published_posts";b:1;}}s:11:"contributor";a:2:{s:4:"name";s:11:"Contributor";s:12:"capabilities";a:5:{s:10:"edit_posts";b:1;s:4:"read";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;}}s:10:"subscriber";a:2:{s:4:"name";s:10:"Subscriber";s:12:"capabilities";a:2:{s:4:"read";b:1;s:7:"level_0";b:1;}}s:13:"wpseo_manager";a:2:{s:4:"name";s:11:"SEO Manager";s:12:"capabilities";a:38:{s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;s:15:"wpseo_bulk_edit";b:1;s:28:"wpseo_edit_advanced_metadata";b:1;s:20:"wpseo_manage_options";b:1;s:23:"view_site_health_checks";b:1;}}s:12:"wpseo_editor";a:2:{s:4:"name";s:10:"SEO Editor";s:12:"capabilities";a:36:{s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;s:15:"wpseo_bulk_edit";b:1;s:28:"wpseo_edit_advanced_metadata";b:1;}}}', 'yes'),
(97, 'fresh_site', '0', 'yes'),
(98, 'widget_search', 'a:2:{i:2;a:1:{s:5:"title";s:0:"";}s:12:"_multiwidget";i:1;}', 'yes'),
(99, 'widget_recent-posts', 'a:2:{i:2;a:2:{s:5:"title";s:0:"";s:6:"number";i:5;}s:12:"_multiwidget";i:1;}', 'yes'),
(100, 'widget_recent-comments', 'a:2:{i:2;a:2:{s:5:"title";s:0:"";s:6:"number";i:5;}s:12:"_multiwidget";i:1;}', 'yes'),
(101, 'widget_archives', 'a:2:{i:2;a:3:{s:5:"title";s:0:"";s:5:"count";i:0;s:8:"dropdown";i:0;}s:12:"_multiwidget";i:1;}', 'yes') ;
INSERT INTO `wp_options` ( `option_id`, `option_name`, `option_value`, `autoload`) VALUES
(102, 'widget_meta', 'a:2:{i:2;a:1:{s:5:"title";s:0:"";}s:12:"_multiwidget";i:1;}', 'yes'),
(103, 'sidebars_widgets', 'a:4:{s:19:"wp_inactive_widgets";a:6:{i:0;s:8:"search-2";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";i:3;s:10:"archives-2";i:4;s:12:"categories-2";i:5;s:6:"meta-2";}s:13:"widget-area-1";a:0:{}s:13:"widget-area-2";a:0:{}s:13:"array_version";i:3;}', 'yes'),
(104, 'cron', 'a:11:{i:1662926606;a:1:{s:34:"wp_privacy_delete_old_export_files";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:6:"hourly";s:4:"args";a:0:{}s:8:"interval";i:3600;}}}i:1662930205;a:1:{s:32:"recovery_mode_clean_expired_keys";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1662930206;a:3:{s:16:"wp_version_check";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:17:"wp_update_plugins";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:16:"wp_update_themes";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}i:1662930216;a:2:{s:19:"wp_scheduled_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}s:25:"delete_expired_transients";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1662930218;a:1:{s:30:"wp_scheduled_auto_draft_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1662930661;a:1:{s:19:"wpseo-reindex-links";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1662965463;a:1:{s:18:"wp_https_detection";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}i:1662966052;a:1:{s:21:"wp_update_user_counts";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}i:1663017061;a:1:{s:16:"wpseo_ryte_fetch";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:6:"weekly";s:4:"args";a:0:{}s:8:"interval";i:604800;}}}i:1663103005;a:1:{s:30:"wp_site_health_scheduled_check";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:6:"weekly";s:4:"args";a:0:{}s:8:"interval";i:604800;}}}s:7:"version";i:2;}', 'yes'),
(105, 'widget_pages', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(106, 'widget_calendar', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(107, 'widget_media_audio', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(108, 'widget_media_image', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(109, 'widget_media_gallery', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(110, 'widget_media_video', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(111, 'widget_tag_cloud', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(112, 'widget_nav_menu', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(113, 'widget_custom_html', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(115, 'recovery_keys', 'a:0:{}', 'yes'),
(117, 'theme_mods_twentytwenty', 'a:2:{s:18:"custom_css_post_id";i:-1;s:16:"sidebars_widgets";a:2:{s:4:"time";i:1600723060;s:4:"data";a:3:{s:19:"wp_inactive_widgets";a:0:{}s:9:"sidebar-1";a:3:{i:0;s:8:"search-2";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";}s:9:"sidebar-2";a:3:{i:0;s:10:"archives-2";i:1;s:12:"categories-2";i:2;s:6:"meta-2";}}}}', 'yes'),
(143, 'finished_updating_comment_type', '1', 'yes'),
(148, 'recently_activated', 'a:0:{}', 'yes'),
(150, 'category_children', 'a:0:{}', 'yes'),
(156, 'sm_uci_pro_settings', 'a:5:{s:10:"debug_mode";s:3:"off";s:14:"send_log_email";s:2:"on";s:10:"drop_table";s:3:"off";s:20:"author_editor_access";s:3:"off";s:10:"woocomattr";s:3:"off";}', 'yes'),
(157, 'ULTIMATE_CSV_IMP_VERSION', '5.7', 'yes'),
(158, 'WP_ULTIMATE_SELECTED_ADDON_Users', 'unchecked', 'yes'),
(159, 'WP_ULTIMATE_SELECTED_ADDON_WooCommerce', 'unchecked', 'yes'),
(160, 'WP_ULTIMATE_SELECTED_ADDON_Exporter', 'unchecked', 'yes'),
(161, 'akeebabackupwp_config', '{"timezone":"UTC"}', 'no'),
(162, 'akeebabackupwp_plugin_dir', 'akeebabackupwp', 'yes'),
(165, 'wpseo', 'a:30:{s:8:"tracking";b:0;s:22:"license_server_version";b:0;s:15:"ms_defaults_set";b:0;s:40:"ignore_search_engines_discouraged_notice";b:0;s:25:"ignore_indexation_warning";b:0;s:29:"indexation_warning_hide_until";b:0;s:18:"indexation_started";b:0;s:28:"indexables_indexation_reason";s:0:"";s:31:"indexables_indexation_completed";b:0;s:7:"version";s:4:"14.9";s:16:"previous_version";s:0:"";s:20:"disableadvanced_meta";b:1;s:30:"enable_headless_rest_endpoints";b:1;s:17:"ryte_indexability";b:1;s:11:"baiduverify";s:0:"";s:12:"googleverify";s:0:"";s:8:"msverify";s:0:"";s:12:"yandexverify";s:0:"";s:9:"site_type";s:0:"";s:20:"has_multiple_authors";s:0:"";s:16:"environment_type";s:0:"";s:23:"content_analysis_active";b:1;s:23:"keyword_analysis_active";b:1;s:21:"enable_admin_bar_menu";b:1;s:26:"enable_cornerstone_content";b:1;s:18:"enable_xml_sitemap";b:1;s:24:"enable_text_link_counter";b:1;s:22:"show_onboarding_notice";b:1;s:18:"first_activated_on";i:1600722661;s:13:"myyoast-oauth";b:0;}', 'yes'),
(166, 'yoast_migrations_free', 'a:1:{s:7:"version";s:4:"14.9";}', 'yes'),
(167, 'wpseo_titles', 'a:73:{s:17:"forcerewritetitle";b:0;s:9:"separator";s:7:"sc-dash";s:16:"title-home-wpseo";s:42:"%%sitename%% %%page%% %%sep%% %%sitedesc%%";s:18:"title-author-wpseo";s:41:"%%name%%, Author at %%sitename%% %%page%%";s:19:"title-archive-wpseo";s:38:"%%date%% %%page%% %%sep%% %%sitename%%";s:18:"title-search-wpseo";s:63:"You searched for %%searchphrase%% %%page%% %%sep%% %%sitename%%";s:15:"title-404-wpseo";s:35:"Page not found %%sep%% %%sitename%%";s:19:"metadesc-home-wpseo";s:0:"";s:21:"metadesc-author-wpseo";s:0:"";s:22:"metadesc-archive-wpseo";s:0:"";s:9:"rssbefore";s:0:"";s:8:"rssafter";s:53:"The post %%POSTLINK%% appeared first on %%BLOGLINK%%.";s:20:"noindex-author-wpseo";b:0;s:28:"noindex-author-noposts-wpseo";b:1;s:21:"noindex-archive-wpseo";b:1;s:14:"disable-author";b:0;s:12:"disable-date";b:0;s:19:"disable-post_format";b:0;s:18:"disable-attachment";b:1;s:23:"is-media-purge-relevant";b:0;s:20:"breadcrumbs-404crumb";s:25:"Error 404: Page not found";s:29:"breadcrumbs-display-blog-page";b:1;s:20:"breadcrumbs-boldlast";b:0;s:25:"breadcrumbs-archiveprefix";s:12:"Archives for";s:18:"breadcrumbs-enable";b:0;s:16:"breadcrumbs-home";s:4:"Home";s:18:"breadcrumbs-prefix";s:0:"";s:24:"breadcrumbs-searchprefix";s:16:"You searched for";s:15:"breadcrumbs-sep";s:7:"&raquo;";s:12:"website_name";s:0:"";s:11:"person_name";s:0:"";s:11:"person_logo";s:0:"";s:14:"person_logo_id";i:0;s:22:"alternate_website_name";s:0:"";s:12:"company_logo";s:0:"";s:15:"company_logo_id";i:0;s:12:"company_name";s:0:"";s:17:"company_or_person";s:7:"company";s:25:"company_or_person_user_id";b:0;s:17:"stripcategorybase";b:0;s:10:"title-post";s:39:"%%title%% %%page%% %%sep%% %%sitename%%";s:13:"metadesc-post";s:0:"";s:12:"noindex-post";b:0;s:23:"display-metabox-pt-post";b:1;s:23:"post_types-post-maintax";i:0;s:21:"schema-page-type-post";s:7:"WebPage";s:24:"schema-article-type-post";s:7:"Article";s:10:"title-page";s:39:"%%title%% %%page%% %%sep%% %%sitename%%";s:13:"metadesc-page";s:0:"";s:12:"noindex-page";b:0;s:23:"display-metabox-pt-page";b:1;s:23:"post_types-page-maintax";i:0;s:21:"schema-page-type-page";s:7:"WebPage";s:24:"schema-article-type-page";s:4:"None";s:16:"title-attachment";s:39:"%%title%% %%page%% %%sep%% %%sitename%%";s:19:"metadesc-attachment";s:0:"";s:18:"noindex-attachment";b:0;s:29:"display-metabox-pt-attachment";b:1;s:29:"post_types-attachment-maintax";i:0;s:27:"schema-page-type-attachment";s:7:"WebPage";s:30:"schema-article-type-attachment";s:4:"None";s:18:"title-tax-category";s:53:"%%term_title%% Archives %%page%% %%sep%% %%sitename%%";s:21:"metadesc-tax-category";s:0:"";s:28:"display-metabox-tax-category";b:1;s:20:"noindex-tax-category";b:0;s:18:"title-tax-post_tag";s:53:"%%term_title%% Archives %%page%% %%sep%% %%sitename%%";s:21:"metadesc-tax-post_tag";s:0:"";s:28:"display-metabox-tax-post_tag";b:1;s:20:"noindex-tax-post_tag";b:0;s:21:"title-tax-post_format";s:53:"%%term_title%% Archives %%page%% %%sep%% %%sitename%%";s:24:"metadesc-tax-post_format";s:0:"";s:31:"display-metabox-tax-post_format";b:1;s:23:"noindex-tax-post_format";b:1;}', 'yes'),
(168, 'wpseo_social', 'a:19:{s:13:"facebook_site";s:0:"";s:13:"instagram_url";s:0:"";s:12:"linkedin_url";s:0:"";s:11:"myspace_url";s:0:"";s:16:"og_default_image";s:0:"";s:19:"og_default_image_id";s:0:"";s:18:"og_frontpage_title";s:0:"";s:17:"og_frontpage_desc";s:0:"";s:18:"og_frontpage_image";s:0:"";s:21:"og_frontpage_image_id";s:0:"";s:9:"opengraph";b:1;s:13:"pinterest_url";s:0:"";s:15:"pinterestverify";s:0:"";s:7:"twitter";b:1;s:12:"twitter_site";s:0:"";s:17:"twitter_card_type";s:19:"summary_large_image";s:11:"youtube_url";s:0:"";s:13:"wikipedia_url";s:0:"";s:10:"fbadminapp";s:0:"";}', 'yes'),
(169, 'wpseo_flush_rewrite', '1', 'yes'),
(171, 'acf_version', '5.12.3', 'yes'),
(172, 'wpseo_ryte', 'a:2:{s:6:"status";i:-1;s:10:"last_fetch";i:1649867319;}', 'yes'),
(186, 'rewrite_rules', 'a:119:{s:12:"locations/?$";s:29:"index.php?post_type=locations";s:42:"locations/feed/(feed|rdf|rss|rss2|atom)/?$";s:46:"index.php?post_type=locations&feed=$matches[1]";s:37:"locations/(feed|rdf|rss|rss2|atom)/?$";s:46:"index.php?post_type=locations&feed=$matches[1]";s:29:"locations/page/([0-9]{1,})/?$";s:47:"index.php?post_type=locations&paged=$matches[1]";s:11:"^wp-json/?$";s:22:"index.php?rest_route=/";s:14:"^wp-json/(.*)?";s:33:"index.php?rest_route=/$matches[1]";s:21:"^index.php/wp-json/?$";s:22:"index.php?rest_route=/";s:24:"^index.php/wp-json/(.*)?";s:33:"index.php?rest_route=/$matches[1]";s:17:"^wp-sitemap\\.xml$";s:23:"index.php?sitemap=index";s:17:"^wp-sitemap\\.xsl$";s:36:"index.php?sitemap-stylesheet=sitemap";s:23:"^wp-sitemap-index\\.xsl$";s:34:"index.php?sitemap-stylesheet=index";s:48:"^wp-sitemap-([a-z]+?)-([a-z\\d_-]+?)-(\\d+?)\\.xml$";s:75:"index.php?sitemap=$matches[1]&sitemap-subtype=$matches[2]&paged=$matches[3]";s:34:"^wp-sitemap-([a-z]+?)-(\\d+?)\\.xml$";s:47:"index.php?sitemap=$matches[1]&paged=$matches[2]";s:47:"category/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:42:"category/(.+?)/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:23:"category/(.+?)/embed/?$";s:46:"index.php?category_name=$matches[1]&embed=true";s:35:"category/(.+?)/page/?([0-9]{1,})/?$";s:53:"index.php?category_name=$matches[1]&paged=$matches[2]";s:17:"category/(.+?)/?$";s:35:"index.php?category_name=$matches[1]";s:44:"tag/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?tag=$matches[1]&feed=$matches[2]";s:39:"tag/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?tag=$matches[1]&feed=$matches[2]";s:20:"tag/([^/]+)/embed/?$";s:36:"index.php?tag=$matches[1]&embed=true";s:32:"tag/([^/]+)/page/?([0-9]{1,})/?$";s:43:"index.php?tag=$matches[1]&paged=$matches[2]";s:14:"tag/([^/]+)/?$";s:25:"index.php?tag=$matches[1]";s:45:"type/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?post_format=$matches[1]&feed=$matches[2]";s:40:"type/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?post_format=$matches[1]&feed=$matches[2]";s:21:"type/([^/]+)/embed/?$";s:44:"index.php?post_format=$matches[1]&embed=true";s:33:"type/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?post_format=$matches[1]&paged=$matches[2]";s:15:"type/([^/]+)/?$";s:33:"index.php?post_format=$matches[1]";s:35:"locations/.+?/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:45:"locations/.+?/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:65:"locations/.+?/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:60:"locations/.+?/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:60:"locations/.+?/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:41:"locations/.+?/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:24:"locations/(.+?)/embed/?$";s:42:"index.php?locations=$matches[1]&embed=true";s:28:"locations/(.+?)/trackback/?$";s:36:"index.php?locations=$matches[1]&tb=1";s:48:"locations/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:48:"index.php?locations=$matches[1]&feed=$matches[2]";s:43:"locations/(.+?)/(feed|rdf|rss|rss2|atom)/?$";s:48:"index.php?locations=$matches[1]&feed=$matches[2]";s:36:"locations/(.+?)/page/?([0-9]{1,})/?$";s:49:"index.php?locations=$matches[1]&paged=$matches[2]";s:43:"locations/(.+?)/comment-page-([0-9]{1,})/?$";s:49:"index.php?locations=$matches[1]&cpage=$matches[2]";s:32:"locations/(.+?)(?:/([0-9]+))?/?$";s:48:"index.php?locations=$matches[1]&page=$matches[2]";s:48:"subject/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?subjects=$matches[1]&feed=$matches[2]";s:43:"subject/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?subjects=$matches[1]&feed=$matches[2]";s:24:"subject/([^/]+)/embed/?$";s:41:"index.php?subjects=$matches[1]&embed=true";s:36:"subject/([^/]+)/page/?([0-9]{1,})/?$";s:48:"index.php?subjects=$matches[1]&paged=$matches[2]";s:18:"subject/([^/]+)/?$";s:30:"index.php?subjects=$matches[1]";s:12:"robots\\.txt$";s:18:"index.php?robots=1";s:13:"favicon\\.ico$";s:19:"index.php?favicon=1";s:48:".*wp-(atom|rdf|rss|rss2|feed|commentsrss2)\\.php$";s:18:"index.php?feed=old";s:20:".*wp-app\\.php(/.*)?$";s:19:"index.php?error=403";s:18:".*wp-register.php$";s:23:"index.php?register=true";s:32:"feed/(feed|rdf|rss|rss2|atom)/?$";s:27:"index.php?&feed=$matches[1]";s:27:"(feed|rdf|rss|rss2|atom)/?$";s:27:"index.php?&feed=$matches[1]";s:8:"embed/?$";s:21:"index.php?&embed=true";s:20:"page/?([0-9]{1,})/?$";s:28:"index.php?&paged=$matches[1]";s:27:"comment-page-([0-9]{1,})/?$";s:39:"index.php?&page_id=30&cpage=$matches[1]";s:41:"comments/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?&feed=$matches[1]&withcomments=1";s:36:"comments/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?&feed=$matches[1]&withcomments=1";s:17:"comments/embed/?$";s:21:"index.php?&embed=true";s:44:"search/(.+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?s=$matches[1]&feed=$matches[2]";s:39:"search/(.+)/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?s=$matches[1]&feed=$matches[2]";s:20:"search/(.+)/embed/?$";s:34:"index.php?s=$matches[1]&embed=true";s:32:"search/(.+)/page/?([0-9]{1,})/?$";s:41:"index.php?s=$matches[1]&paged=$matches[2]";s:14:"search/(.+)/?$";s:23:"index.php?s=$matches[1]";s:47:"author/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?author_name=$matches[1]&feed=$matches[2]";s:42:"author/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?author_name=$matches[1]&feed=$matches[2]";s:23:"author/([^/]+)/embed/?$";s:44:"index.php?author_name=$matches[1]&embed=true";s:35:"author/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?author_name=$matches[1]&paged=$matches[2]";s:17:"author/([^/]+)/?$";s:33:"index.php?author_name=$matches[1]";s:69:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:64:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:45:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/embed/?$";s:74:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&embed=true";s:57:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:81:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&paged=$matches[4]";s:39:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/?$";s:63:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]";s:56:"([0-9]{4})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:51:"([0-9]{4})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:32:"([0-9]{4})/([0-9]{1,2})/embed/?$";s:58:"index.php?year=$matches[1]&monthnum=$matches[2]&embed=true";s:44:"([0-9]{4})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:65:"index.php?year=$matches[1]&monthnum=$matches[2]&paged=$matches[3]";s:26:"([0-9]{4})/([0-9]{1,2})/?$";s:47:"index.php?year=$matches[1]&monthnum=$matches[2]";s:43:"([0-9]{4})/feed/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?year=$matches[1]&feed=$matches[2]";s:38:"([0-9]{4})/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?year=$matches[1]&feed=$matches[2]";s:19:"([0-9]{4})/embed/?$";s:37:"index.php?year=$matches[1]&embed=true";s:31:"([0-9]{4})/page/?([0-9]{1,})/?$";s:44:"index.php?year=$matches[1]&paged=$matches[2]";s:13:"([0-9]{4})/?$";s:26:"index.php?year=$matches[1]";s:58:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:68:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:88:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:83:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:83:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:64:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:53:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/embed/?$";s:91:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&embed=true";s:57:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/trackback/?$";s:85:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&tb=1";s:77:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:97:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&feed=$matches[5]";s:72:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:97:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&feed=$matches[5]";s:65:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/page/?([0-9]{1,})/?$";s:98:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&paged=$matches[5]";s:72:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/comment-page-([0-9]{1,})/?$";s:98:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&cpage=$matches[5]";s:61:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)(?:/([0-9]+))?/?$";s:97:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&page=$matches[5]";s:47:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:57:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:77:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:72:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:72:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:53:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:64:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/comment-page-([0-9]{1,})/?$";s:81:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&cpage=$matches[4]";s:51:"([0-9]{4})/([0-9]{1,2})/comment-page-([0-9]{1,})/?$";s:65:"index.php?year=$matches[1]&monthnum=$matches[2]&cpage=$matches[3]";s:38:"([0-9]{4})/comment-page-([0-9]{1,})/?$";s:44:"index.php?year=$matches[1]&cpage=$matches[2]";s:27:".?.+?/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:37:".?.+?/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:57:".?.+?/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:".?.+?/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:".?.+?/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:33:".?.+?/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:16:"(.?.+?)/embed/?$";s:41:"index.php?pagename=$matches[1]&embed=true";s:20:"(.?.+?)/trackback/?$";s:35:"index.php?pagename=$matches[1]&tb=1";s:40:"(.?.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:35:"(.?.+?)/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:28:"(.?.+?)/page/?([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&paged=$matches[2]";s:35:"(.?.+?)/comment-page-([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&cpage=$matches[2]";s:24:"(.?.+?)(?:/([0-9]+))?/?$";s:47:"index.php?pagename=$matches[1]&page=$matches[2]";}', 'yes'),
(191, 'leadin_did_disconnect', '1', 'yes'),
(195, 'leadin_portalId', '5952677', 'yes'),
(196, 'leadin_account_name', 'NowRx', 'yes'),
(197, 'leadin_portal_domain', 'www.nowrx.com', 'yes'),
(203, 'current_theme', '', 'yes'),
(204, 'theme_mods_html5blank-stable', 'a:3:{i:0;b:0;s:18:"nav_menu_locations";a:0:{}s:16:"sidebars_widgets";a:2:{s:4:"time";i:1600727268;s:4:"data";a:3:{s:19:"wp_inactive_widgets";a:6:{i:0;s:8:"search-2";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";i:3;s:10:"archives-2";i:4;s:12:"categories-2";i:5;s:6:"meta-2";}s:13:"widget-area-1";a:0:{}s:13:"widget-area-2";a:0:{}}}}', 'yes'),
(205, 'theme_switched', '', 'yes'),
(210, 'theme_mods_nowrx', 'a:3:{i:0;b:0;s:18:"nav_menu_locations";a:0:{}s:18:"custom_css_post_id";i:-1;}', 'yes'),
(278, 'auto_core_update_notified', 'a:4:{s:4:"type";s:7:"success";s:5:"email";s:22:"jeff.barnett@nowrx.com";s:7:"version";s:5:"5.5.9";s:9:"timestamp";i:1649867316;}', 'no'),
(279, 'widget_block', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(288, 'auto_update_core_dev', 'enabled', 'yes'),
(289, 'auto_update_core_minor', 'enabled', 'yes'),
(290, 'auto_update_core_major', 'unset', 'yes'),
(291, 'wp_force_deactivated_plugins', 'a:0:{}', 'yes'),
(292, 'user_count', '5', 'no'),
(293, 'db_upgraded', '', 'yes'),
(294, 'https_detection_errors', 'a:1:{s:20:"https_request_failed";a:1:{i:0;s:21:"HTTPS request failed.";}}', 'yes'),
(298, 'can_compress_scripts', '0', 'no'),
(332, 'wpmdb_usage', 'a:2:{s:6:"action";s:8:"savefile";s:4:"time";i:1662923348;}', 'no') ;

#
# End of data contents of table `wp_options`
# --------------------------------------------------------



#
# Delete any existing table `wp_postmeta`
#

DROP TABLE IF EXISTS `wp_postmeta`;


#
# Table structure of table `wp_postmeta`
#

CREATE TABLE `wp_postmeta` (
  `meta_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `post_id` bigint unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`meta_id`),
  KEY `post_id` (`post_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=277 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_postmeta`
#
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(1, 2, '_wp_page_template', 'default'),
(2, 3, '_wp_page_template', 'default'),
(7, 8, '_wp_page_template', 'default'),
(8, 9, '_wp_page_template', 'page-single-col.php'),
(9, 9, '_edit_last', '4'),
(10, 9, '_schema_ref', '267'),
(11, 9, '_schema_json', 'a:10:{s:8:"@context";s:18:"http://schema.org/";s:5:"@type";s:7:"Article";s:16:"mainEntityOfPage";a:2:{s:5:"@type";s:7:"WebPage";s:3:"@id";s:45:"https://www-staging.nowrx.com/privacy-policy/";}s:3:"url";s:45:"https://www-staging.nowrx.com/privacy-policy/";s:8:"headline";s:10:"Privacy...";s:13:"datePublished";s:25:"2019-09-05T04:45:54+00:00";s:12:"dateModified";s:25:"2019-10-13T16:42:00+00:00";s:9:"publisher";a:4:{s:5:"@type";s:12:"Organization";s:3:"@id";s:43:"https://www-staging.nowrx.com/#organization";s:4:"name";s:14:"NowRx Pharmacy";s:4:"logo";a:4:{s:5:"@type";s:11:"ImageObject";s:3:"url";s:67:"http://nowrx.com/wp-content/uploads/2019/12/NowRx-Schema-Upload.png";s:5:"width";i:600;s:6:"height";i:60;}}s:11:"description";s:383:"I. Introduction.NowRx, Inc. (“NowRx”, “we”, “us”, or “our”) operates the website located at www.nowrx.com and other related websites and mobile applications with links to this Privacy Policy (collectively, the “Site”). Through the Site, we operate an online service enabling members (“Members”) to receive telehealth services from various healthcare providers";s:6:"author";a:5:{s:5:"@type";s:6:"Person";s:4:"name";s:14:"NowRx Pharmacy";s:3:"url";s:57:"https://www-staging.nowrx.com/blog/author/nowrx-pharmacy/";s:5:"image";a:4:{s:5:"@type";s:11:"ImageObject";s:3:"url";s:79:"https://www-staging.nowrx.com/wp-content/uploads/2020/01/500x500-NowRx-Logo.png";s:6:"height";i:96;s:5:"width";i:96;}s:6:"sameAs";a:1:{i:0;s:16:"http://nowrx.com";}}}'),
(12, 9, '_schema_json_timestamp', '1598461624'),
(13, 10, '_wp_page_template', 'page-about-us.php'),
(14, 10, 'large_page_title', 'The Modern Pharmacy'),
(15, 10, '_large_page_title', 'field_5dfa3551ee57c'),
(16, 10, 'page_intro', 'One day in early 2015, Cary Breese left his doctor\'s office with a prescription in hand and drove across town to his local pharmacy where he found himself waiting in three separate lines: the first to drop off the prescription, the second to pay (after a 20 minute wait for the medication to be counted out by hand!), and the third to speak to the pharmacist. Cary found himself thinking: in the world of on-demand where you can order a car to pick you up within a few minutes, or have practically any retail product delivered to your doorstep, how can it be that pharmacy still requires you to drive to a pharmacy, stand in multiple lines, and often wait for 20-30 minutes or more for your prescription to be prepared?\n\nCary immediately called his friend and former work colleague, Sumeet Sheokand, NowRx\'s current CTO and together they researched the industry and surrounded themselves with industry experts. Cary and Sumeet jumped in and NowRx was born.\n\nFour years later NowRx has 5 licensed facilities spread across the San Francisco Bay area, Orange County, and Los Angeles, and has delivered more than 100,000 prescriptions to 18,000 customers.'),
(17, 10, '_page_intro', 'field_5dfa355c61835'),
(18, 10, 'handwriting', 'Meet our executive team…'),
(19, 10, '_handwriting', 'field_5dfa3571b434a'),
(20, 10, 'cary_breese', '<h2>Cary Breese</h2>\n<p class="about-us--team-member-title">CEO AND FOUNDER</p>\nSuccessful, multiple time startup CEO, expertise in technology, healthcare and financial services. CEO of database software startup GenieDB. COO of technology incubator focused on developing innovative technologies in Healthcare. CEO and founder of bootstrapped financial services startup, acquired for 18x cash-on-cash. Led $100M product line as EVP, CIGNA. B.S. in Electrical Engineering from Drexel University and credentialed Actuary (ACAS).\n\n<a href="https://www.linkedin.com/in/carybreese/">Connect on Linkedin</a>'),
(21, 10, '_cary_breese', 'field_5dfa359342fcd'),
(22, 10, 'sumeet_sheokand', '<h2>Sumeet Sheokand</h2>\n<p class="about-us--team-member-title">CTO AND FOUNDER</p>\n15+ years senior technology leadership in software and technology startups. Previously CTO, GenieDB; VP Engineering at enterprise search startup X1. Extensive expertise in building business line software and utilizing Big Data techniques to solve real business problems.\n\n<a href="https://www.linkedin.com/in/sumeetsheokand/">Connect on Linkedin</a>'),
(23, 10, '_sumeet_sheokand', 'field_5dfa359fa044d'),
(24, 10, 'michael_rosenberg', '<h2>Michael Rosenberg</h2>\n<p class="about-us--team-member-title">CHIEF REVENUE OFFICER</p>\nA senior marketing and sales executive with extensive experience growing, managing and scaling businesses as CMO, CRO and COO. Expertise in Branding, Lead Gen, Marketing, Online Advertising, Sales, Strategy, Ops, and Bus Dev at start ups and Fortune 500 companies like Procter &amp; Gamble, HJ Heinz, AOL and Bain &amp; Co.\n\n<a href="https://www.linkedin.com/in/mikerosenberglagunabeach/">Connect on Linkedin</a>'),
(25, 10, '_michael_rosenberg', 'field_5dfa35a62e6fd'),
(26, 10, 'handwriting_2', 'Meet our pharmacists…'),
(27, 10, '_handwriting_2', 'field_5dfae7daac483'),
(28, 10, 'melissa_bostock', '<h2>Melissa Bostock</h2>\n<p class="about-us--team-member-title">Director of Pharmacy — Mountain View</p>\nMelissa Bostock obtained her Doctor of Pharmacy (Pharm D) from UCSF and she holds a Masters Degree in Public Health and a Bachelor of Science degree in Microbiology, Immunology and Molecular Genetics from UCLA. Melissa is trained in diabetes screening, pain management, pediatrics, immunizations and medication therapy management. Prior to NowRx, Melissa spent several years as Managing Pharmacist at Target.\n\n<a href="https://www.linkedin.com/in/melissa-bostock-7a1b9065/">Connect on Linkedin</a>'),
(29, 10, '_melissa_bostock', 'field_5dfa35afe2cac'),
(30, 10, 'laemsing_root', '<h2>Laemsing Root</h2>\n<p class="about-us--team-member-title">Pharmacist-in-Charge — Irvine</p>\nLaemsing obtained her Doctor of Pharmacy (Pharm D) from Touro University and she holds a Bachelor of Arts in English Literature from UCLA. Laemsing is trained in diabetes and blood pressure screening, medication therapy management and immunizations. Prior to NowRx, Laemsing spent over 9 years as a Pharmacy Manager and Staff Pharmacist at Target and CVS.'),
(31, 10, '_laemsing_root', 'field_5dfa35bad91df'),
(32, 10, '_yoast_wpseo_title', 'About Us | NowRx ® Pharmacy - Prescription Delivery Made Easy'),
(33, 10, '_yoast_wpseo_metadesc', 'NowRx Pharmacy provides free prescription delivery in under 5 hours. Learn more about NowRx and the team that has rebuilt pharmacy from the ground up.'),
(34, 10, '_schema_ref', '268'),
(35, 10, '_at_widget', '1'),
(36, 10, '_wpassetcleanup_no_load', '{"styles":["addthis_all_pages"],"scripts":["addthis_widget"]}'),
(37, 10, '_schema_json', ''),
(38, 10, '_schema_json_timestamp', '1598492539'),
(39, 11, '_edit_last', '5'),
(40, 11, '_schema_ref', '268'),
(41, 11, '_at_widget', '1'),
(42, 11, '_yoast_wpseo_title', 'Blog | NowRx ® Pharmacy - Prescription Delivery Made Easy'),
(43, 12, '_wp_page_template', 'page-careers.php'),
(44, 12, 'large_page_title', 'Get In on the Ground Floor of a Hyper-Growth Startup'),
(45, 12, '_large_page_title', 'field_5dfb89e7f38ef'),
(46, 12, 'page_intro', 'Get in on the ground floor of a hyper-growth startup set to disrupt the $250B pharmacy industry. NowRx is poised to revolutionize the pharmacy industry with state-of-the art technology and business processes, transforming an industry that has not changed substantially in more than 150 years.\n\nInterested?\n\nTake a leadership role in this once-in-a-generation opportunity to transform retail pharmacy into a next generation business model: <strong>On-Demand Pharmacy.</strong>'),
(47, 12, '_page_intro', 'field_5dfb8a00bdd0a'),
(48, 12, 'current_openings', 'Current Openings'),
(49, 12, '_current_openings', 'field_5dfb8a182f4bb'),
(50, 12, 'job_openings', '12'),
(51, 12, '_job_openings', 'field_5dfb8a4374194'),
(52, 12, 'job_openings_0_job_title', 'Pharmacy Technician - Orange County, CA'),
(53, 12, '_job_openings_0_job_title', 'field_5dfb8a7674195'),
(54, 12, 'job_openings_0_job_details', '<h3>Pharmacists</h3>\nAs one the pharmacists on the team you will have a unique opportunity to impact our efforts to scale our business model nationwide. Candidates should be able to thrive in a dynamic environment and be excited by the opportunity to help reshape an industry. As we scale the model, there will be opportunity to recruit and lead a team of pharmacists across multiple locations.\n\n<strong>As Pharmacist you will be responsible for day to day pharmacy operations, including but not limited to the following duties:</strong>\n<ul>\n 	<li>Accept and dispense prescription medications.</li>\n 	<li>Provide consultation on prescription medications for storage, dosage, side effects, and drug interactions.</li>\n 	<li>Supervise pharmacy staff members including pharmacy technicians,pharmacy clerks, etc.</li>\n 	<li>Proper management of patient records and pharmacy files.</li>\n 	<li>Maintain appropriate inventory on pharmaceutical and medical supplies.</li>\n 	<li>Identify patient’s drug-related problems and effectively communicate with physicians and other healthcare practitioners.</li>\n 	<li>Work in conjunction with physicians, nurses, other pharmacists, pharmacy interns, etc.</li>\n 	<li>Comply with state and federal drug laws as regulated by the state board of pharmacy, the drug enforcement administration, and the food and drug administration.</li>\n 	<li>Maintain current registration; study existing and new legislation; Advise management on needed actions.</li>\n 	<li>Maintain safe and clean working environment by complying with procedures, rules, and regulations.</li>\n 	<li>Maintain pharmacological knowledge by attending educational workshops; review professional publications; establish personal networks; participate in professional societies.</li>\n</ul>\n&nbsp;\n\n<strong>Requirements:</strong>\n<ul>\n 	<li>Entrepreneurial spirit and ability to work with small, fast-paced teams.</li>\n 	<li>Creative and passionate regarding ways to reshape the industry.</li>\n 	<li>4 years pharmacy education program.</li>\n 	<li>Must be licensed to practice.</li>\n</ul>\n&nbsp;\n\nCompetitive compensation package including equity.\n\n<a class="button rounded large" href="https://www.fountain.com/nowrx/apply/irvine-ca-pharm-tech?preview=true">Apply Now</a>'),
(55, 12, '_job_openings_0_job_details', 'field_5dfb8a8774196'),
(56, 12, 'job_openings_1_job_title', 'Physician Outreach Representative - Orange County, CA'),
(57, 12, '_job_openings_1_job_title', 'field_5dfb8a7674195'),
(58, 12, 'job_openings_1_job_details', '<h3>Physician Outreach Representative</h3>\nAs Physician Outreach Representative, you will be responsible for establishing and maintaining professional relationships with healthcare providers within a defined territory. You will support the Company’s growth objectives through collaboration with the pharmacy team, as well as the following duties:\n<ul>\n 	<li>Interact with physician offices and other venues of care (hospitals, AHECs, RHCs, etc.) through on­site or telephonic visits. Provide education and feedback regarding the NowRx service.</li>\n 	<li>Assist in the development, production, maintenance and delivery of promotional materials/activities.</li>\n 	<li>Assist in the creation and maintenance of necessary reports and additional documents to track and report referral activity by provider. Assist with preparation of onthly reports and/or statistics as directed.</li>\n 	<li>Stay abreast of and comply with state and federal drug laws as regulated by the state board of pharmacy, the drug enforcement administration, and the food and drug administration.</li>\n</ul>\n<a class="button rounded large" href="https://www.fountain.com/nowrx/apply/irvine-ca-physician-outreach-representative?preview=true">Apply Now</a>'),
(59, 12, '_job_openings_1_job_details', 'field_5dfb8a8774196'),
(60, 12, 'job_openings_2_job_title', 'Delivery Driver - Orange County CA Area'),
(61, 12, '_job_openings_2_job_title', 'field_5dfb8a7674195'),
(62, 12, 'job_openings_2_job_details', '<h3>Delivery Person</h3>\nAs a NowRx Delivery Person, you will be responsible for delivering small packaged healthcare items from local NowRx facilities to customer homes and businesses. Company vehicle is available to perform deliveries. No heavy lifting required, as packages are very small. Some training required for deliveries of certain items that require special handling. Must be very customer focused and be able to communicate in a friendly and professional manner. he right customer-focused individual will be able to grow with the company into larger roles with increasing responsibility.\n\n<strong>Background checks will be performed and driver record will be closely scrutinized.</strong>\n<ul>\n 	<li>Deliver items by identifying destinations; establishing route; operating the company vehicle; maintaining schedule.</li>\n 	<li>Must be very customer service oriented. Be eager to understand and resolve complaints; adjusting orders and routes as appropriate.</li>\n 	<li>No handling of cash should be necessary, as all payments are received by company electronically before items leave facility.</li>\n 	<li>Maintains safe operation and clean appearance by complying with organization operational policies, procedures, and standards, as well as state and local driving rules and regulations.</li>\n</ul>\n<a class="button rounded large" href="https://www.fountain.com/nowrx/apply/irvine-ca-driver?preview=true">Apply Now</a>'),
(63, 12, '_job_openings_2_job_details', 'field_5dfb8a8774196'),
(64, 12, '_schema_ref', '268'),
(65, 12, '_at_widget', '1'),
(66, 12, 'job_openings_3_job_title', 'Delivery Driver - SF Bay Area - Peninsula'),
(67, 12, '_job_openings_3_job_title', 'field_5dfb8a7674195'),
(68, 12, 'job_openings_3_job_details', '<h3>Delivery Person</h3>\nAs a NowRx Delivery Person, you will be responsible for delivering small packaged healthcare items from local NowRx facilities to customer homes and businesses. Company vehicle is available to perform deliveries. No heavy lifting required, as packages are very small. Some training required for deliveries of certain items that require special handling. Must be very customer focused and be able to communicate in a friendly and professional manner. he right customer-focused individual will be able to grow with the company into larger roles with increasing responsibility.\n\n<strong>Background checks will be performed and driver record will be closely scrutinized.</strong>\n<ul>\n 	<li>Deliver items by identifying destinations; establishing route; operating the company vehicle; maintaining schedule.</li>\n 	<li>Must be very customer service oriented. Be eager to understand and resolve complaints; adjusting orders and routes as appropriate.</li>\n 	<li>No handling of cash should be necessary, as all payments are received by company electronically before items leave facility.</li>\n 	<li>Maintains safe operation and clean appearance by complying with organization operational policies, procedures, and standards, as well as state and local driving rules and regulations.</li>\n</ul>\n<a class="button rounded large" href="https://www.fountain.com/nowrx/apply/mountain-view-hq-driver?preview=true">Apply Now</a>'),
(69, 12, '_job_openings_3_job_details', 'field_5dfb8a8774196'),
(70, 12, '_yoast_wpseo_title', 'Careers | NowRx ® Pharmacy - Prescription Delivery Made Easy'),
(71, 12, '_yoast_wpseo_metadesc', 'NowRx is a local pharmacy that offers free prescription delivery in under 5 hours. Get prescriptions and medication delivered with NowRx Pharmacy!'),
(72, 12, 'job_openings_4_job_title', 'Delivery Driver - SF Bay Area - South Bay'),
(73, 12, '_job_openings_4_job_title', 'field_5dfb8a7674195'),
(74, 12, 'job_openings_4_job_details', '<h3>Delivery Person</h3>\nAs a NowRx Delivery Person, you will be responsible for delivering small packaged healthcare items from local NowRx facilities to customer homes and businesses. Company vehicle is available to perform deliveries. No heavy lifting required, as packages are very small. Some training required for deliveries of certain items that require special handling. Must be very customer focused and be able to communicate in a friendly and professional manner. he right customer-focused individual will be able to grow with the company into larger roles with increasing responsibility.\n\n<strong>Background checks will be performed and driver record will be closely scrutinized.</strong>\n<ul>\n 	<li>Deliver items by identifying destinations; establishing route; operating the company vehicle; maintaining schedule.</li>\n 	<li>Must be very customer service oriented. Be eager to understand and resolve complaints; adjusting orders and routes as appropriate.</li>\n 	<li>No handling of cash should be necessary, as all payments are received by company electronically before items leave facility.</li>\n 	<li>Maintains safe operation and clean appearance by complying with organization operational policies, procedures, and standards, as well as state and local driving rules and regulations.</li>\n</ul>\n<a class="button rounded large" href="https://www.fountain.com/nowrx/apply/mountain-view-hq-driver?preview=true">Apply Now</a>'),
(75, 12, '_job_openings_4_job_details', 'field_5dfb8a8774196'),
(76, 12, 'job_openings_5_job_title', 'Delivery Driver - SF Bay Area - East Bay'),
(77, 12, '_job_openings_5_job_title', 'field_5dfb8a7674195'),
(78, 12, 'job_openings_5_job_details', '<h3>Delivery Person</h3>\nAs a NowRx Delivery Person, you will be responsible for delivering small packaged healthcare items from local NowRx facilities to customer homes and businesses. Company vehicle is available to perform deliveries. No heavy lifting required, as packages are very small. Some training required for deliveries of certain items that require special handling. Must be very customer focused and be able to communicate in a friendly and professional manner. he right customer-focused individual will be able to grow with the company into larger roles with increasing responsibility.\n\n<strong>Background checks will be performed and driver record will be closely scrutinized.</strong>\n<ul>\n 	<li>Deliver items by identifying destinations; establishing route; operating the company vehicle; maintaining schedule.</li>\n 	<li>Must be very customer service oriented. Be eager to understand and resolve complaints; adjusting orders and routes as appropriate.</li>\n 	<li>No handling of cash should be necessary, as all payments are received by company electronically before items leave facility.</li>\n 	<li>Maintains safe operation and clean appearance by complying with organization operational policies, procedures, and standards, as well as state and local driving rules and regulations.</li>\n</ul>\n<a class="button rounded large" href="https://www.fountain.com/nowrx/apply/mountain-view-hq-driver?preview=true">Apply Now</a>'),
(79, 12, '_job_openings_5_job_details', 'field_5dfb8a8774196'),
(80, 12, 'job_openings_6_job_title', 'Delivery Driver - SF Bay Area - Dowtown'),
(81, 12, '_job_openings_6_job_title', 'field_5dfb8a7674195'),
(82, 12, 'job_openings_6_job_details', '<h3>Delivery Person</h3>\nAs a NowRx Delivery Person, you will be responsible for delivering small packaged healthcare items from local NowRx facilities to customer homes and businesses. Company vehicle is available to perform deliveries. No heavy lifting required, as packages are very small. Some training required for deliveries of certain items that require special handling. Must be very customer focused and be able to communicate in a friendly and professional manner. he right customer-focused individual will be able to grow with the company into larger roles with increasing responsibility.\n\n<strong>Background checks will be performed and driver record will be closely scrutinized.</strong>\n<ul>\n 	<li>Deliver items by identifying destinations; establishing route; operating the company vehicle; maintaining schedule.</li>\n 	<li>Must be very customer service oriented. Be eager to understand and resolve complaints; adjusting orders and routes as appropriate.</li>\n 	<li>No handling of cash should be necessary, as all payments are received by company electronically before items leave facility.</li>\n 	<li>Maintains safe operation and clean appearance by complying with organization operational policies, procedures, and standards, as well as state and local driving rules and regulations.</li>\n</ul>\n<a class="button rounded large" href="https://www.fountain.com/nowrx/apply/mountain-view-hq-driver?preview=true">Apply Now</a>'),
(83, 12, '_job_openings_6_job_details', 'field_5dfb8a8774196'),
(84, 12, 'job_openings_7_job_title', 'Delivery Driver - Sacramento CA Area'),
(85, 12, '_job_openings_7_job_title', 'field_5dfb8a7674195'),
(86, 12, 'job_openings_7_job_details', '<h3>Delivery Person</h3>\nAs a NowRx Delivery Person, you will be responsible for delivering small packaged healthcare items from local NowRx facilities to customer homes and businesses. Company vehicle is available to perform deliveries. No heavy lifting required, as packages are very small. Some training required for deliveries of certain items that require special handling. Must be very customer focused and be able to communicate in a friendly and professional manner. he right customer-focused individual will be able to grow with the company into larger roles with increasing responsibility.\n\n<strong>Background checks will be performed and driver record will be closely scrutinized.</strong>\n<ul>\n 	<li>Deliver items by identifying destinations; establishing route; operating the company vehicle; maintaining schedule.</li>\n 	<li>Must be very customer service oriented. Be eager to understand and resolve complaints; adjusting orders and routes as appropriate.</li>\n 	<li>No handling of cash should be necessary, as all payments are received by company electronically before items leave facility.</li>\n 	<li>Maintains safe operation and clean appearance by complying with organization operational policies, procedures, and standards, as well as state and local driving rules and regulations.</li>\n</ul>\n<a class="button rounded large" href="https://www.fountain.com/nowrx/apply/mountain-view-hq-driver?preview=true">Apply Now</a>'),
(87, 12, '_job_openings_7_job_details', 'field_5dfb8a8774196'),
(88, 12, 'job_openings_8_job_title', 'Delivery Driver - Los Angeles CA Area'),
(89, 12, '_job_openings_8_job_title', 'field_5dfb8a7674195'),
(90, 12, 'job_openings_8_job_details', '<h3>Delivery Person</h3>\nAs a NowRx Delivery Person, you will be responsible for delivering small packaged healthcare items from local NowRx facilities to customer homes and businesses. Company vehicle is available to perform deliveries. No heavy lifting required, as packages are very small. Some training required for deliveries of certain items that require special handling. Must be very customer focused and be able to communicate in a friendly and professional manner. he right customer-focused individual will be able to grow with the company into larger roles with increasing responsibility.\n\n<strong>Background checks will be performed and driver record will be closely scrutinized.</strong>\n<ul>\n 	<li>Deliver items by identifying destinations; establishing route; operating the company vehicle; maintaining schedule.</li>\n 	<li>Must be very customer service oriented. Be eager to understand and resolve complaints; adjusting orders and routes as appropriate.</li>\n 	<li>No handling of cash should be necessary, as all payments are received by company electronically before items leave facility.</li>\n 	<li>Maintains safe operation and clean appearance by complying with organization operational policies, procedures, and standards, as well as state and local driving rules and regulations.</li>\n</ul>\n<a class="button rounded large" href="https://www.fountain.com/nowrx/apply/mountain-view-hq-driver?preview=true">Apply Now</a>'),
(91, 12, '_job_openings_8_job_details', 'field_5dfb8a8774196'),
(92, 12, 'job_openings_9_job_title', 'Delivery Driver - Seattle WA Area'),
(93, 12, '_job_openings_9_job_title', 'field_5dfb8a7674195'),
(94, 12, 'job_openings_9_job_details', '<h3>Delivery Person</h3>\nAs a NowRx Delivery Person, you will be responsible for delivering small packaged healthcare items from local NowRx facilities to customer homes and businesses. Company vehicle is available to perform deliveries. No heavy lifting required, as packages are very small. Some training required for deliveries of certain items that require special handling. Must be very customer focused and be able to communicate in a friendly and professional manner. he right customer-focused individual will be able to grow with the company into larger roles with increasing responsibility.\n\n<strong>Background checks will be performed and driver record will be closely scrutinized.</strong>\n<ul>\n 	<li>Deliver items by identifying destinations; establishing route; operating the company vehicle; maintaining schedule.</li>\n 	<li>Must be very customer service oriented. Be eager to understand and resolve complaints; adjusting orders and routes as appropriate.</li>\n 	<li>No handling of cash should be necessary, as all payments are received by company electronically before items leave facility.</li>\n 	<li>Maintains safe operation and clean appearance by complying with organization operational policies, procedures, and standards, as well as state and local driving rules and regulations.</li>\n</ul>\n<a class="button rounded large" href="https://www.fountain.com/nowrx/apply/mountain-view-hq-driver?preview=true">Apply Now</a>'),
(95, 12, '_job_openings_9_job_details', 'field_5dfb8a8774196'),
(96, 12, 'job_openings_10_job_title', 'Delivery Driver - Las Vegas NV Area'),
(97, 12, '_job_openings_10_job_title', 'field_5dfb8a7674195'),
(98, 12, 'job_openings_10_job_details', '<h3>Delivery Person</h3>\nAs a NowRx Delivery Person, you will be responsible for delivering small packaged healthcare items from local NowRx facilities to customer homes and businesses. Company vehicle is available to perform deliveries. No heavy lifting required, as packages are very small. Some training required for deliveries of certain items that require special handling. Must be very customer focused and be able to communicate in a friendly and professional manner. he right customer-focused individual will be able to grow with the company into larger roles with increasing responsibility.\n\n<strong>Background checks will be performed and driver record will be closely scrutinized.</strong>\n<ul>\n 	<li>Deliver items by identifying destinations; establishing route; operating the company vehicle; maintaining schedule.</li>\n 	<li>Must be very customer service oriented. Be eager to understand and resolve complaints; adjusting orders and routes as appropriate.</li>\n 	<li>No handling of cash should be necessary, as all payments are received by company electronically before items leave facility.</li>\n 	<li>Maintains safe operation and clean appearance by complying with organization operational policies, procedures, and standards, as well as state and local driving rules and regulations.</li>\n</ul>\n<a class="button rounded large" href="https://www.fountain.com/nowrx/apply/mountain-view-hq-driver?preview=true">Apply Now</a>'),
(99, 12, '_job_openings_10_job_details', 'field_5dfb8a8774196'),
(100, 12, 'job_openings_11_job_title', 'Delivery Driver - Phoenix AZ Area'),
(101, 12, '_job_openings_11_job_title', 'field_5dfb8a7674195'),
(102, 12, 'job_openings_11_job_details', '<h3>Delivery Person</h3>\nAs a NowRx Delivery Person, you will be responsible for delivering small packaged healthcare items from local NowRx facilities to customer homes and businesses. Company vehicle is available to perform deliveries. No heavy lifting required, as packages are very small. Some training required for deliveries of certain items that require special handling. Must be very customer focused and be able to communicate in a friendly and professional manner. he right customer-focused individual will be able to grow with the company into larger roles with increasing responsibility.\n\n<strong>Background checks will be performed and driver record will be closely scrutinized.</strong>\n<ul>\n 	<li>Deliver items by identifying destinations; establishing route; operating the company vehicle; maintaining schedule.</li>\n 	<li>Must be very customer service oriented. Be eager to understand and resolve complaints; adjusting orders and routes as appropriate.</li>\n 	<li>No handling of cash should be necessary, as all payments are received by company electronically before items leave facility.</li>\n 	<li>Maintains safe operation and clean appearance by complying with organization operational policies, procedures, and standards, as well as state and local driving rules and regulations.</li>\n</ul>\n<a class="button rounded large" href="https://www.fountain.com/nowrx/apply/mountain-view-hq-driver?preview=true">Apply Now</a>'),
(103, 12, '_job_openings_11_job_details', 'field_5dfb8a8774196'),
(104, 12, '_wpassetcleanup_no_load', '{"styles":["addthis_all_pages"],"scripts":["addthis_widget"]}') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(105, 12, '_schema_json', 'a:9:{s:8:"@context";s:18:"http://schema.org/";s:5:"@type";s:7:"Article";s:16:"mainEntityOfPage";a:2:{s:5:"@type";s:7:"WebPage";s:3:"@id";s:38:"https://www-staging.nowrx.com/careers/";}s:3:"url";s:38:"https://www-staging.nowrx.com/careers/";s:8:"headline";s:3:"...";s:13:"datePublished";s:25:"2019-09-23T13:45:33+00:00";s:12:"dateModified";s:25:"2020-08-18T18:49:54+00:00";s:9:"publisher";a:4:{s:5:"@type";s:12:"Organization";s:3:"@id";s:43:"https://www-staging.nowrx.com/#organization";s:4:"name";s:14:"NowRx Pharmacy";s:4:"logo";a:4:{s:5:"@type";s:11:"ImageObject";s:3:"url";s:67:"http://nowrx.com/wp-content/uploads/2019/12/NowRx-Schema-Upload.png";s:5:"width";i:600;s:6:"height";i:60;}}s:6:"author";a:5:{s:5:"@type";s:6:"Person";s:4:"name";s:12:"Jose Mendoza";s:3:"url";s:47:"https://www-staging.nowrx.com/blog/author/jose/";s:5:"image";a:4:{s:5:"@type";s:11:"ImageObject";s:3:"url";s:81:"https://secure.gravatar.com/avatar/cf79e57683f947e8eed034159e82487a?s=96&d=mm&r=g";s:6:"height";i:96;s:5:"width";i:96;}s:6:"sameAs";a:1:{i:0;s:19:"http://uituners.com";}}}'),
(106, 12, '_schema_json_timestamp', '1598461568'),
(107, 14, '_wp_page_template', 'default'),
(108, 14, '_schema_ref', '268'),
(109, 14, '_wpassetcleanup_no_load', '{"styles":["addthis_all_pages"],"scripts":["addthis_widget"]}'),
(110, 14, '_at_widget', '1'),
(111, 14, '_yoast_wpseo_content_score', '90'),
(112, 14, '_schema_json', ''),
(113, 14, '_schema_json_timestamp', '1598550587'),
(114, 16, '_wp_page_template', 'page-for-doctors.php'),
(115, 16, 'large_page_title', 'Join the Thousands of Doctors Using NowRx Pharmacy!'),
(116, 16, '_large_page_title', 'field_5df83f2248c9a'),
(117, 16, 'page_intro', '<p style="text-align: center; margin-bottom: 2em;">The retail pharmacy model is broken - inconvenient, inefficient, and a major headache for doctors &amp; patients alike. NowRx is changing that by using modern technology to provide a simpler, more convenient pharmacy experience.</p>'),
(118, 16, '_page_intro', 'field_5df843247f3f9'),
(119, 16, 'page_intro_cta_text', 'Join the 4,500 physicians that have chosen NowRx for a better pharmacy experience!'),
(120, 16, '_page_intro_cta_text', 'field_5df843357f3fa'),
(121, 16, 'handwritten_text_under_button', 'A Better Pharmacy'),
(122, 16, '_handwritten_text_under_button', 'field_5df844eb39c60'),
(123, 16, 'benefits_for_nowrx_doctors', 'Benefits for Doctors'),
(124, 16, '_benefits_for_nowrx_doctors', 'field_5df84594ac8fb'),
(125, 16, 'benefits_for_nowrx_doctors_bullets', '<ul>\n 	<li>Free medication delivery in hours for all patients</li>\n 	<li>Dedicated customer support to assist office staff</li>\n 	<li>Streamlined prior-auths save staff time &amp; energy</li>\n 	<li>Auto-applied drug coupons for all patients</li>\n 	<li>Robotic automation dispensing reduces errors</li>\n</ul>'),
(126, 16, '_benefits_for_nowrx_doctors_bullets', 'field_5df845a8ac8fc'),
(127, 16, 'benefits_for_nowrx_patients', 'Benefits for Patients'),
(128, 16, '_benefits_for_nowrx_patients', 'field_5df846887da9f'),
(129, 16, 'benefits_for_nowrx_patients_bullets', '<ul>\n 	<li>Medications delivered in hours for no fee</li>\n 	<li>Auto-applied drug coupons &amp; low cash prices</li>\n 	<li>All major insurance plans accepted</li>\n 	<li>Pharmacist consultations always available</li>\n 	<li><a href="https://www.yelp.com/biz/nowrx-mountain-view-3">5-Star rating from customers on Yelp </a></li>\n</ul>'),
(130, 16, '_benefits_for_nowrx_patients_bullets', 'field_5df846974b4a1'),
(131, 16, '_schema_ref', '268'),
(132, 16, '_at_widget', '1'),
(133, 16, '_yoast_wpseo_title', 'For Doctors | NowRx ® Pharmacy - Prescription Delivery Made Easy'),
(134, 16, '_yoast_wpseo_metadesc', 'Retail pharmacies are a major headache for doctors and patients to deal with. Learn how NowRx has helped thousands discover a better pharmacy experience.'),
(135, 16, '_wpassetcleanup_no_load', '{"styles":["addthis_all_pages"],"scripts":["addthis_widget"]}'),
(136, 16, '_schema_json', 'a:9:{s:8:"@context";s:18:"http://schema.org/";s:5:"@type";s:7:"Article";s:16:"mainEntityOfPage";a:2:{s:5:"@type";s:7:"WebPage";s:3:"@id";s:42:"https://www-staging.nowrx.com/for-doctors/";}s:3:"url";s:42:"https://www-staging.nowrx.com/for-doctors/";s:8:"headline";s:12:"NowRx For...";s:13:"datePublished";s:25:"2019-09-23T13:46:39+00:00";s:12:"dateModified";s:25:"2020-08-18T18:38:54+00:00";s:9:"publisher";a:4:{s:5:"@type";s:12:"Organization";s:3:"@id";s:43:"https://www-staging.nowrx.com/#organization";s:4:"name";s:14:"NowRx Pharmacy";s:4:"logo";a:4:{s:5:"@type";s:11:"ImageObject";s:3:"url";s:67:"http://nowrx.com/wp-content/uploads/2019/12/NowRx-Schema-Upload.png";s:5:"width";i:600;s:6:"height";i:60;}}s:6:"author";a:5:{s:5:"@type";s:6:"Person";s:4:"name";s:12:"Jose Mendoza";s:3:"url";s:47:"https://www-staging.nowrx.com/blog/author/jose/";s:5:"image";a:4:{s:5:"@type";s:11:"ImageObject";s:3:"url";s:81:"https://secure.gravatar.com/avatar/cf79e57683f947e8eed034159e82487a?s=96&d=mm&r=g";s:6:"height";i:96;s:5:"width";i:96;}s:6:"sameAs";a:1:{i:0;s:19:"http://uituners.com";}}}'),
(137, 16, '_schema_json_timestamp', '1598648374'),
(138, 16, '_edit_last', '1'),
(139, 18, '_edit_last', '5'),
(140, 18, '_wp_page_template', 'page-get-started.php'),
(141, 18, 'large_page_title', 'Prescription Delivery in Hours. Free!'),
(142, 18, '_large_page_title', 'field_5df84a8467db3'),
(143, 18, 'page_intro', 'Get a <strong>$20 Visa Gift Card</strong> for every prescription you transfer to NowRx* and have your prescription delivered right to your door.\n\n&nbsp;'),
(144, 18, '_page_intro', 'field_5df84a94fed9e'),
(145, 18, 'new_prescription', 'Simply tell your doctor that your pharmacy is NowRx and they\'ll automatically send your prescription to us.\n\n— or —\n\nText a picture of your paper prescription to (844) 466-6979.*'),
(146, 18, '_new_prescription', 'field_5df84abb28d99'),
(147, 18, 'new_prescription_-_legal', '*Photos of paper prescriptions uploaded through the app are not valid for processing. This only serves as a notification to us. We will send a driver to get the paper prescription from you. The paper prescription is verified once received at the pharmacy and then proceeds with processing as normal.'),
(148, 18, '_new_prescription_-_legal', 'field_5df84af8947dc'),
(149, 18, 'transfer_your_prescription', 'It is easy to transfer your existing prescription for free to NowRx.\n\nCall us at\n(844) 466-6979.\n\n— or —\n\nText us a picture of your prescription label to\n(844) 466-6979.'),
(150, 18, '_transfer_your_prescription', 'field_5df84acf51269'),
(151, 18, 'no_active_prescription', 'If you don\'t have a prescription yet, but want to use NowRx when you get your next one: Email us at info@NowRx.com to let us know and we will walk you through making NowRx your default pharmacy for all future prescriptions!'),
(152, 18, '_no_active_prescription', 'field_5df84ad9ffb82'),
(153, 18, '_schema_ref', '268'),
(154, 18, '_at_widget', '1'),
(155, 18, '_yoast_wpseo_title', 'Free Prescription Delivery in Hours - Get Started | NowRx ®'),
(156, 18, '_yoast_wpseo_metadesc', 'Prescription delivery right to your door. We deliver all prescriptions including controlled & refridgerated meds! No delivery fees - Get started in minutes!'),
(157, 18, '_yoast_wpseo_focuskw', 'prescription delivery'),
(158, 18, '_yoast_wpseo_linkdex', '42'),
(159, 18, '_schema_json', 'a:9:{s:8:"@context";s:18:"http://schema.org/";s:5:"@type";s:7:"Article";s:16:"mainEntityOfPage";a:2:{s:5:"@type";s:7:"WebPage";s:3:"@id";s:42:"https://www-staging.nowrx.com/get-started/";}s:3:"url";s:42:"https://www-staging.nowrx.com/get-started/";s:8:"headline";s:14:"Get Started...";s:13:"datePublished";s:25:"2019-09-23T13:46:43+00:00";s:12:"dateModified";s:25:"2020-05-21T16:08:07+00:00";s:9:"publisher";a:4:{s:5:"@type";s:12:"Organization";s:3:"@id";s:43:"https://www-staging.nowrx.com/#organization";s:4:"name";s:14:"NowRx Pharmacy";s:4:"logo";a:4:{s:5:"@type";s:11:"ImageObject";s:3:"url";s:67:"http://nowrx.com/wp-content/uploads/2019/12/NowRx-Schema-Upload.png";s:5:"width";i:600;s:6:"height";i:60;}}s:6:"author";a:5:{s:5:"@type";s:6:"Person";s:4:"name";s:12:"Jose Mendoza";s:3:"url";s:47:"https://www-staging.nowrx.com/blog/author/jose/";s:5:"image";a:4:{s:5:"@type";s:11:"ImageObject";s:3:"url";s:81:"https://secure.gravatar.com/avatar/cf79e57683f947e8eed034159e82487a?s=96&d=mm&r=g";s:6:"height";i:96;s:5:"width";i:96;}s:6:"sameAs";a:1:{i:0;s:19:"http://uituners.com";}}}'),
(160, 18, '_schema_json_timestamp', '1598571253'),
(161, 20, '_wp_page_template', 'page-how-it-works.php'),
(162, 20, 'large_page_title', 'Prescriptions Delivered in Hours!'),
(163, 20, '_large_page_title', 'field_5dfa34563f4c8'),
(164, 20, 'page_intro', ''),
(165, 20, '_page_intro', 'field_5dfa346d8f002'),
(166, 20, 'handwriting', 'A Better Pharmacy...'),
(167, 20, '_handwriting', 'field_5dfa347d8e2cb'),
(168, 20, 'current_prescription', '<h2>Transfer It to NowRx</h2>\nTransfer an existing prescription to NowRx in minutes through our <a href="https://try.nowrxpharmacy.com/prescription-delivery">online form</a> or text a photo of your prescription bottle label to (844) 466-6979.\n\n<a href="https://try.nowrxpharmacy.com/prescription-delivery">Transfer Prescriptions to NowRx Pharmacy</a>'),
(169, 20, '_current_prescription', 'field_5dfa348bc2155'),
(170, 20, 'new_prescription', '<h2>Fill It with NowRx</h2>\nShow your doctor the following information.\n\n<strong>ePrescribe to:</strong> NowRx\n<strong>Phone:</strong> (844) 466-6979\n\nYou can also make NowRx Pharmacy your default pharmacy and have all your future prescriptions delivered right to your door.\n\n<a href="https://try.nowrxpharmacy.com/prescription-delivery">Make NowRx My Default Pharmacy</a>'),
(171, 20, '_new_prescription', 'field_5dfa34cc464d5'),
(172, 20, 'prescription_questions', '<h2>Talk With a Pharmacist</h2>\nChat 1-on-1 with a licensed NowRx pharmacist over the phone and get all your prescription questions answered in minutes.\n\n<a data-toggle="modal-example">Chat With a NowRx Pharmacist in Minutes</a>'),
(173, 20, '_prescription_questions', 'field_5dfa34dc5e738'),
(174, 20, 'robotics', '<h2>High-Tech = A Better Pharmacy</h2>\nProprietary technology &amp; low overhead make us extremely efficient, which means prescription delivery in hours and exceptional customer service at the same price as your normal copay!\n\n<a href="https://nowrx.com/blog/how-nowrx-pharmacy-offers-free-medication-delivery-in-hours/">How NowRx Affords Free Prescription Delivery</a>'),
(175, 20, '_robotics', 'field_5dfa34ebbc7bf'),
(176, 20, 'delivery', '<h2>Delivered in Hours</h2>\nOur HIPPA trained NowRx drivers will bring your prescription right to your door in one of our environmentally friendly electric cars - completely free! You can use our app to schedule and track your delivery.\n\n<a href="https://try.nowrxpharmacy.com/prescription-delivery">Get Started with NowRx in Minutes</a>'),
(177, 20, '_delivery', 'field_5dfa34fa07bcb'),
(178, 20, 'relax', '<h2>We Come To You</h2>\nNo more standing in line at the Pharmacy. Get home, sit down, grab a snack or read a book. As long as you order it before 5:00PM we’ll deliver to your house (or work!) that same day.\n\n<a href="https://try.nowrxpharmacy.com/prescription-delivery">Get Started with NowRx in Minutes</a>'),
(179, 20, '_relax', 'field_5dfa350888fe1'),
(180, 20, 'refills', '<h2>One-Click Refills</h2>\nNeed a refill? Just let us know using the NowRx App. Want us to deliver it every month automatically? Want us to call and remind you before we deliver your refill? Just log in and set your preferences and that’s what we’ll do. It couldn’t be easier.\n\n<a href="https://try.nowrxpharmacy.com/prescription-delivery">Request a Refill from NowRx Pharmacy</a>'),
(181, 20, '_refills', 'field_5dfa3515810f5'),
(182, 20, 'download_the_app', '<h2>Get Ultimate Control</h2>\nThe NowRx App makes NowRx even easier to use. One click refills, delivery preferences, track your delivery, Pharmacist video chat, and more. It’s like a pharmacy in the palm of your hand!'),
(183, 20, '_download_the_app', 'field_5dfa352f2c2cf'),
(184, 20, '_schema_ref', '268'),
(185, 20, '_at_widget', '1'),
(186, 20, '_yoast_wpseo_title', 'How it Works - Prescription Delivery in Hours for Free | NowRx ®'),
(187, 20, '_yoast_wpseo_metadesc', 'NowRx is a local pharmacy that delivers all medications including controlled meds for no delivery fee! Learn how it works and sign up in minutes!'),
(188, 20, '_wpassetcleanup_no_load', '{"styles":["addthis_all_pages"],"scripts":["addthis_widget"]}'),
(189, 20, '_schema_json', 'a:9:{s:8:"@context";s:18:"http://schema.org/";s:5:"@type";s:7:"Article";s:16:"mainEntityOfPage";a:2:{s:5:"@type";s:7:"WebPage";s:3:"@id";s:43:"https://www-staging.nowrx.com/how-it-works/";}s:3:"url";s:43:"https://www-staging.nowrx.com/how-it-works/";s:8:"headline";s:9:"How It...";s:13:"datePublished";s:25:"2019-09-23T13:46:46+00:00";s:12:"dateModified";s:25:"2020-08-18T18:33:45+00:00";s:9:"publisher";a:4:{s:5:"@type";s:12:"Organization";s:3:"@id";s:43:"https://www-staging.nowrx.com/#organization";s:4:"name";s:14:"NowRx Pharmacy";s:4:"logo";a:4:{s:5:"@type";s:11:"ImageObject";s:3:"url";s:67:"http://nowrx.com/wp-content/uploads/2019/12/NowRx-Schema-Upload.png";s:5:"width";i:600;s:6:"height";i:60;}}s:6:"author";a:5:{s:5:"@type";s:6:"Person";s:4:"name";s:12:"Jose Mendoza";s:3:"url";s:47:"https://www-staging.nowrx.com/blog/author/jose/";s:5:"image";a:4:{s:5:"@type";s:11:"ImageObject";s:3:"url";s:81:"https://secure.gravatar.com/avatar/cf79e57683f947e8eed034159e82487a?s=96&d=mm&r=g";s:6:"height";i:96;s:5:"width";i:96;}s:6:"sameAs";a:1:{i:0;s:19:"http://uituners.com";}}}'),
(190, 20, '_schema_json_timestamp', '1598648674'),
(191, 22, '_schema_ref', '268'),
(192, 22, '_wp_page_template', 'default'),
(193, 22, '_at_widget', '1'),
(194, 22, '_yoast_wpseo_title', 'Locations | NowRx ® Pharmacy - Prescription Delivery Made Easy'),
(195, 22, '_yoast_wpseo_metadesc', 'NowRx is a local pharmacy that offers free prescription delivery in under 5 hours. Learn more about available career and job opportunities with NowRx.'),
(196, 22, '_wpassetcleanup_no_load', '{"styles":["addthis_all_pages"],"scripts":["addthis_widget"]}'),
(197, 22, '_schema_json', 'a:9:{s:8:"@context";s:18:"http://schema.org/";s:5:"@type";s:7:"Article";s:16:"mainEntityOfPage";a:2:{s:5:"@type";s:7:"WebPage";s:3:"@id";s:40:"https://www-staging.nowrx.com/locations/";}s:3:"url";s:40:"https://www-staging.nowrx.com/locations/";s:8:"headline";s:3:"...";s:13:"datePublished";s:25:"2019-09-23T13:46:50+00:00";s:12:"dateModified";s:25:"2020-08-18T18:47:40+00:00";s:9:"publisher";a:4:{s:5:"@type";s:12:"Organization";s:3:"@id";s:43:"https://www-staging.nowrx.com/#organization";s:4:"name";s:14:"NowRx Pharmacy";s:4:"logo";a:4:{s:5:"@type";s:11:"ImageObject";s:3:"url";s:67:"http://nowrx.com/wp-content/uploads/2019/12/NowRx-Schema-Upload.png";s:5:"width";i:600;s:6:"height";i:60;}}s:6:"author";a:5:{s:5:"@type";s:6:"Person";s:4:"name";s:12:"Jose Mendoza";s:3:"url";s:47:"https://www-staging.nowrx.com/blog/author/jose/";s:5:"image";a:4:{s:5:"@type";s:11:"ImageObject";s:3:"url";s:81:"https://secure.gravatar.com/avatar/cf79e57683f947e8eed034159e82487a?s=96&d=mm&r=g";s:6:"height";i:96;s:5:"width";i:96;}s:6:"sameAs";a:1:{i:0;s:19:"http://uituners.com";}}}'),
(198, 22, '_schema_json_timestamp', '1598550594'),
(199, 24, '_edit_last', '5'),
(200, 24, '_schema_ref', '268'),
(201, 24, '_wp_page_template', 'page-press.php'),
(202, 24, '_at_widget', '1'),
(203, 24, '_yoast_wpseo_title', 'Press | NowRx ® Pharmacy - Prescription Delivery Made Easy'),
(204, 24, '_schema_json', 'a:10:{s:8:"@context";s:18:"http://schema.org/";s:5:"@type";s:7:"Article";s:16:"mainEntityOfPage";a:2:{s:5:"@type";s:7:"WebPage";s:3:"@id";s:36:"https://www-staging.nowrx.com/press/";}s:3:"url";s:36:"https://www-staging.nowrx.com/press/";s:8:"headline";s:3:"...";s:13:"datePublished";s:25:"2019-09-23T13:46:54+00:00";s:12:"dateModified";s:25:"2020-02-26T00:25:34+00:00";s:9:"publisher";a:4:{s:5:"@type";s:12:"Organization";s:3:"@id";s:43:"https://www-staging.nowrx.com/#organization";s:4:"name";s:14:"NowRx Pharmacy";s:4:"logo";a:4:{s:5:"@type";s:11:"ImageObject";s:3:"url";s:67:"http://nowrx.com/wp-content/uploads/2019/12/NowRx-Schema-Upload.png";s:5:"width";i:600;s:6:"height";i:60;}}s:11:"description";s:4:"jose";s:6:"author";a:5:{s:5:"@type";s:6:"Person";s:4:"name";s:12:"Jose Mendoza";s:3:"url";s:47:"https://www-staging.nowrx.com/blog/author/jose/";s:5:"image";a:4:{s:5:"@type";s:11:"ImageObject";s:3:"url";s:81:"https://secure.gravatar.com/avatar/cf79e57683f947e8eed034159e82487a?s=96&d=mm&r=g";s:6:"height";i:96;s:5:"width";i:96;}s:6:"sameAs";a:1:{i:0;s:19:"http://uituners.com";}}}') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(205, 24, '_schema_json_timestamp', '1598461652'),
(206, 30, '_wp_page_template', 'default'),
(207, 30, '_yoast_wpseo_focuskw', 'pharmacy delivery'),
(208, 30, '_yoast_wpseo_title', 'Prescription Delivery in Hours for Free | NowRx ®'),
(209, 30, '_yoast_wpseo_metadesc', 'Prescription delivery right to your door. We deliver all medication including controlled and over the counter. No delivery fees - Get started in minutes!'),
(210, 30, '_yoast_wpseo_linkdex', '25'),
(211, 30, '_schema_ref', '268'),
(212, 30, '_at_widget', '1'),
(213, 30, '_wpassetcleanup_no_load', '{"styles":["addthis_all_pages"],"scripts":["addthis_widget"]}'),
(214, 46, '_edit_last', '4'),
(215, 46, '_wp_page_template', 'default'),
(216, 46, '_schema_ref', '267'),
(217, 46, '_schema_json', 'a:10:{s:8:"@context";s:18:"http://schema.org/";s:5:"@type";s:7:"Article";s:16:"mainEntityOfPage";a:2:{s:5:"@type";s:7:"WebPage";s:3:"@id";s:51:"https://www-staging.nowrx.com/contact-us/thank-you/";}s:3:"url";s:51:"https://www-staging.nowrx.com/contact-us/thank-you/";s:8:"headline";s:8:"Thank...";s:13:"datePublished";s:25:"2019-09-29T22:00:13+00:00";s:12:"dateModified";s:25:"2019-09-29T22:00:13+00:00";s:9:"publisher";a:4:{s:5:"@type";s:12:"Organization";s:3:"@id";s:43:"https://www-staging.nowrx.com/#organization";s:4:"name";s:14:"NowRx Pharmacy";s:4:"logo";a:4:{s:5:"@type";s:11:"ImageObject";s:3:"url";s:67:"http://nowrx.com/wp-content/uploads/2019/12/NowRx-Schema-Upload.png";s:5:"width";i:600;s:6:"height";i:60;}}s:11:"description";s:17:"Contact thank you";s:6:"author";a:5:{s:5:"@type";s:6:"Person";s:4:"name";s:12:"Jose Mendoza";s:3:"url";s:47:"https://www-staging.nowrx.com/blog/author/jose/";s:5:"image";a:4:{s:5:"@type";s:11:"ImageObject";s:3:"url";s:81:"https://secure.gravatar.com/avatar/cf79e57683f947e8eed034159e82487a?s=96&d=mm&r=g";s:6:"height";i:96;s:5:"width";i:96;}s:6:"sameAs";a:1:{i:0;s:19:"http://uituners.com";}}}'),
(218, 46, '_schema_json_timestamp', '1598461669'),
(219, 46, '_at_widget', '1'),
(220, 46, '_yoast_wpseo_content_score', '60'),
(221, 56, '_edit_last', '4'),
(222, 56, '_wp_page_template', 'page-single-col.php'),
(223, 56, '_schema_ref', '267'),
(224, 56, '_schema_json', 'a:10:{s:8:"@context";s:18:"http://schema.org/";s:5:"@type";s:7:"Article";s:16:"mainEntityOfPage";a:2:{s:5:"@type";s:7:"WebPage";s:3:"@id";s:44:"https://www-staging.nowrx.com/hipaa-privacy/";}s:3:"url";s:44:"https://www-staging.nowrx.com/hipaa-privacy/";s:8:"headline";s:20:"Notice of Privacy...";s:13:"datePublished";s:25:"2019-10-13T01:54:10+00:00";s:12:"dateModified";s:25:"2019-10-13T16:42:11+00:00";s:9:"publisher";a:4:{s:5:"@type";s:12:"Organization";s:3:"@id";s:43:"https://www-staging.nowrx.com/#organization";s:4:"name";s:14:"NowRx Pharmacy";s:4:"logo";a:4:{s:5:"@type";s:11:"ImageObject";s:3:"url";s:67:"http://nowrx.com/wp-content/uploads/2019/12/NowRx-Schema-Upload.png";s:5:"width";i:600;s:6:"height";i:60;}}s:11:"description";s:325:"Under the Health Insurance Portability and Accountability Act of 1996 (“HIPAA”), NowRx (“We” or“Us”) is required to provide you with a Notice of Privacy Practices that describes how we may use your information for treatment, payment and other purposes that details your rights regarding the privacy of your health";s:6:"author";a:5:{s:5:"@type";s:6:"Person";s:4:"name";s:12:"Jose Mendoza";s:3:"url";s:47:"https://www-staging.nowrx.com/blog/author/jose/";s:5:"image";a:4:{s:5:"@type";s:11:"ImageObject";s:3:"url";s:81:"https://secure.gravatar.com/avatar/cf79e57683f947e8eed034159e82487a?s=96&d=mm&r=g";s:6:"height";i:96;s:5:"width";i:96;}s:6:"sameAs";a:1:{i:0;s:19:"http://uituners.com";}}}'),
(225, 56, '_schema_json_timestamp', '1598461435'),
(226, 65, '_edit_last', '4'),
(227, 65, '_wp_page_template', 'default'),
(228, 65, '_oembed_b1b37859b4182df6b47eef47cffa36b2', '<blockquote class="wp-embedded-content" data-secret="H3Xqh4Vgui"><a href="http://www.nowrx.com/nowrx-offering-circular-series-b-preferred-pdf/">NowRx Circular Series B Preferred</a></blockquote><iframe title="&#8220;NowRx Circular Series B Preferred&#8221; &#8212; NowRx" class="wp-embedded-content" sandbox="allow-scripts" security="restricted" style="position: absolute; clip: rect(1px, 1px, 1px, 1px);" src="http://www.nowrx.com/nowrx-offering-circular-series-b-preferred-pdf/embed/#?secret=H3Xqh4Vgui" data-secret="H3Xqh4Vgui" width="600" height="338" frameborder="0" marginwidth="0" marginheight="0" scrolling="no"></iframe>'),
(229, 65, '_oembed_time_b1b37859b4182df6b47eef47cffa36b2', '1571759202'),
(230, 65, '_schema_ref', '267'),
(231, 65, '_schema_json', 'a:10:{s:8:"@context";s:18:"http://schema.org/";s:5:"@type";s:7:"Article";s:16:"mainEntityOfPage";a:2:{s:5:"@type";s:7:"WebPage";s:3:"@id";s:77:"https://www-staging.nowrx.com/nowrx-offering-circular-series-b-preferred-pdf/";}s:3:"url";s:77:"https://www-staging.nowrx.com/nowrx-offering-circular-series-b-preferred-pdf/";s:8:"headline";s:35:"NowRx Offering Circular Series B...";s:13:"datePublished";s:25:"2019-10-22T15:45:10+00:00";s:12:"dateModified";s:25:"2019-10-22T15:59:35+00:00";s:9:"publisher";a:4:{s:5:"@type";s:12:"Organization";s:3:"@id";s:43:"https://www-staging.nowrx.com/#organization";s:4:"name";s:14:"NowRx Pharmacy";s:4:"logo";a:4:{s:5:"@type";s:11:"ImageObject";s:3:"url";s:67:"http://nowrx.com/wp-content/uploads/2019/12/NowRx-Schema-Upload.png";s:5:"width";i:600;s:6:"height";i:60;}}s:11:"description";s:288:"You can now invest in NowRx and take part in our journey as we continue to expand our business into other areas of California. NowRx has partnered with SeedInvest to raise money via equity crowdfunding, which means anyone can invest and join NowRx as we revolutionize pharmacy. View NowRx";s:6:"author";a:5:{s:5:"@type";s:6:"Person";s:4:"name";s:12:"Jose Mendoza";s:3:"url";s:47:"https://www-staging.nowrx.com/blog/author/jose/";s:5:"image";a:4:{s:5:"@type";s:11:"ImageObject";s:3:"url";s:81:"https://secure.gravatar.com/avatar/cf79e57683f947e8eed034159e82487a?s=96&d=mm&r=g";s:6:"height";i:96;s:5:"width";i:96;}s:6:"sameAs";a:1:{i:0;s:19:"http://uituners.com";}}}'),
(232, 65, '_schema_json_timestamp', '1598461661'),
(233, 159, '_wp_page_template', 'page-landing-page-2.php'),
(234, 159, '_yoast_wpseo_content_score', '90'),
(235, 159, '_schema_ref', '268'),
(236, 159, '_at_widget', '1'),
(237, 159, '_yoast_wpseo_title', 'Referral Program | NowRx ® Pharmacy - Prescription Delivery Made Easy'),
(238, 159, '_wpassetcleanup_no_load', '{"styles":["addthis_all_pages"],"scripts":["addthis_widget"]}'),
(239, 159, '_schema_json', 'a:10:{s:8:"@context";s:18:"http://schema.org/";s:5:"@type";s:7:"Article";s:16:"mainEntityOfPage";a:2:{s:5:"@type";s:7:"WebPage";s:3:"@id";s:39:"https://www-staging.nowrx.com/referral/";}s:3:"url";s:39:"https://www-staging.nowrx.com/referral/";s:8:"headline";s:23:"Refer Friends - Earn...";s:13:"datePublished";s:25:"2019-11-26T14:46:43+00:00";s:12:"dateModified";s:25:"2020-08-18T18:41:08+00:00";s:9:"publisher";a:4:{s:5:"@type";s:12:"Organization";s:3:"@id";s:43:"https://www-staging.nowrx.com/#organization";s:4:"name";s:14:"NowRx Pharmacy";s:4:"logo";a:4:{s:5:"@type";s:11:"ImageObject";s:3:"url";s:67:"http://nowrx.com/wp-content/uploads/2019/12/NowRx-Schema-Upload.png";s:5:"width";i:600;s:6:"height";i:60;}}s:11:"description";s:290:"&nbsp; If NowRx doesn\'t have an email on file, please email info@NowRx.com so we can update your customer profile. You may view the full list of terms and conditions for NowRx Referral Program Here. Please note that no credits, cash, benefits, rewards, or coupons can be given for referring";s:6:"author";a:5:{s:5:"@type";s:6:"Person";s:4:"name";s:12:"Jose Mendoza";s:3:"url";s:47:"https://www-staging.nowrx.com/blog/author/jose/";s:5:"image";a:4:{s:5:"@type";s:11:"ImageObject";s:3:"url";s:81:"https://secure.gravatar.com/avatar/cf79e57683f947e8eed034159e82487a?s=96&d=mm&r=g";s:6:"height";i:96;s:5:"width";i:96;}s:6:"sameAs";a:1:{i:0;s:19:"http://uituners.com";}}}'),
(240, 159, '_schema_json_timestamp', '1598461351'),
(241, 173, '_edit_last', '5'),
(242, 173, '_wp_page_template', 'default'),
(243, 173, '_yoast_wpseo_content_score', '30'),
(244, 173, '_schema_ref', '268'),
(245, 173, '_at_widget', '1'),
(246, 173, '_schema_json', 'a:10:{s:8:"@context";s:18:"http://schema.org/";s:5:"@type";s:7:"Article";s:16:"mainEntityOfPage";a:2:{s:5:"@type";s:7:"WebPage";s:3:"@id";s:40:"https://www-staging.nowrx.com/thank-you/";}s:3:"url";s:40:"https://www-staging.nowrx.com/thank-you/";s:8:"headline";s:8:"Thank...";s:13:"datePublished";s:25:"2019-12-06T18:06:08+00:00";s:12:"dateModified";s:25:"2019-12-30T23:41:42+00:00";s:9:"publisher";a:4:{s:5:"@type";s:12:"Organization";s:3:"@id";s:43:"https://www-staging.nowrx.com/#organization";s:4:"name";s:14:"NowRx Pharmacy";s:4:"logo";a:4:{s:5:"@type";s:11:"ImageObject";s:3:"url";s:67:"http://nowrx.com/wp-content/uploads/2019/12/NowRx-Schema-Upload.png";s:5:"width";i:600;s:6:"height";i:60;}}s:11:"description";s:289:"Your referrals have been successfully submitted. They will receive an email shortly letting them know you have referred them to NowRx Pharmacy. What\'s next? Follow up with your referrals to make sure they have a prescription filled through NowRx Pharmacy in the next 90 days. At the end of";s:6:"author";a:5:{s:5:"@type";s:6:"Person";s:4:"name";s:14:"NowRx Pharmacy";s:3:"url";s:57:"https://www-staging.nowrx.com/blog/author/nowrx-pharmacy/";s:5:"image";a:4:{s:5:"@type";s:11:"ImageObject";s:3:"url";s:79:"https://www-staging.nowrx.com/wp-content/uploads/2020/01/500x500-NowRx-Logo.png";s:6:"height";i:96;s:5:"width";i:96;}s:6:"sameAs";a:1:{i:0;s:16:"http://nowrx.com";}}}'),
(247, 173, '_schema_json_timestamp', '1598461655'),
(248, 286, '_schema_ref', '268'),
(249, 286, '_wp_page_template', 'page-faq.php'),
(250, 286, '_at_widget', '1'),
(251, 286, '_yoast_wpseo_title', 'FAQs | NowRx ® Pharmacy - Prescription Delivery Made Easy'),
(252, 286, '_yoast_wpseo_metadesc', 'NowRx Pharmacy provides free prescription delivery in under 5 hours. Check out our frequently asked questions paged to learn more.'),
(253, 286, '_wpassetcleanup_no_load', '{"styles":["addthis_all_pages"],"scripts":["addthis_widget"]}'),
(254, 286, '_schema_json', 'a:9:{s:8:"@context";s:18:"http://schema.org/";s:5:"@type";s:7:"Article";s:16:"mainEntityOfPage";a:2:{s:5:"@type";s:7:"WebPage";s:3:"@id";s:35:"https://www-staging.nowrx.com/faqs/";}s:3:"url";s:35:"https://www-staging.nowrx.com/faqs/";s:8:"headline";s:19:"Frequently Asked...";s:13:"datePublished";s:25:"2020-01-16T22:36:48+00:00";s:12:"dateModified";s:25:"2020-08-18T18:43:56+00:00";s:9:"publisher";a:4:{s:5:"@type";s:12:"Organization";s:3:"@id";s:43:"https://www-staging.nowrx.com/#organization";s:4:"name";s:14:"NowRx Pharmacy";s:4:"logo";a:4:{s:5:"@type";s:11:"ImageObject";s:3:"url";s:67:"http://nowrx.com/wp-content/uploads/2019/12/NowRx-Schema-Upload.png";s:5:"width";i:600;s:6:"height";i:60;}}s:6:"author";a:5:{s:5:"@type";s:6:"Person";s:4:"name";s:12:"Jose Mendoza";s:3:"url";s:47:"https://www-staging.nowrx.com/blog/author/jose/";s:5:"image";a:4:{s:5:"@type";s:11:"ImageObject";s:3:"url";s:81:"https://secure.gravatar.com/avatar/cf79e57683f947e8eed034159e82487a?s=96&d=mm&r=g";s:6:"height";i:96;s:5:"width";i:96;}s:6:"sameAs";a:1:{i:0;s:19:"http://uituners.com";}}}'),
(255, 286, '_schema_json_timestamp', '1598648695'),
(256, 286, '_edit_last', '1'),
(257, 493, '_schema_ref', '268'),
(258, 493, '_edit_last', '5'),
(259, 493, '_wp_page_template', 'default'),
(260, 493, '_at_widget', '1'),
(261, 493, '_schema_json', 'a:9:{s:8:"@context";s:18:"http://schema.org/";s:5:"@type";s:7:"Article";s:16:"mainEntityOfPage";a:2:{s:5:"@type";s:7:"WebPage";s:3:"@id";s:55:"https://www-staging.nowrx.com/common-cold-flu-symptoms/";}s:3:"url";s:55:"https://www-staging.nowrx.com/common-cold-flu-symptoms/";s:8:"headline";s:40:"Common Cold and Flu Symptoms Have You...";s:13:"datePublished";s:25:"2020-03-04T20:21:34+00:00";s:12:"dateModified";s:25:"2020-03-04T20:21:53+00:00";s:9:"publisher";a:4:{s:5:"@type";s:12:"Organization";s:3:"@id";s:43:"https://www-staging.nowrx.com/#organization";s:4:"name";s:14:"NowRx Pharmacy";s:4:"logo";a:4:{s:5:"@type";s:11:"ImageObject";s:3:"url";s:67:"http://nowrx.com/wp-content/uploads/2019/12/NowRx-Schema-Upload.png";s:5:"width";i:600;s:6:"height";i:60;}}s:6:"author";a:4:{s:5:"@type";s:6:"Person";s:4:"name";s:10:"Phil Rossi";s:3:"url";s:47:"https://www-staging.nowrx.com/blog/author/phil/";s:5:"image";a:4:{s:5:"@type";s:11:"ImageObject";s:3:"url";s:78:"https://www-staging.nowrx.com/wp-content/uploads/2020/02/WordPress-Image-1.png";s:6:"height";i:96;s:5:"width";i:96;}}}'),
(262, 493, '_schema_json_timestamp', '1598461664'),
(263, 493, '_yoast_wpseo_content_score', '60'),
(264, 621, '_schema_ref', '268'),
(265, 621, '_edit_last', '5'),
(266, 621, '_wp_page_template', 'default'),
(267, 621, '_at_widget', '1'),
(268, 621, '_schema_json', 'a:9:{s:8:"@context";s:18:"http://schema.org/";s:5:"@type";s:7:"Article";s:16:"mainEntityOfPage";a:2:{s:5:"@type";s:7:"WebPage";s:3:"@id";s:40:"https://www-staging.nowrx.com/test-page/";}s:3:"url";s:40:"https://www-staging.nowrx.com/test-page/";s:8:"headline";s:7:"Test...";s:13:"datePublished";s:25:"2020-04-14T22:48:45+00:00";s:12:"dateModified";s:25:"2020-04-14T22:48:45+00:00";s:9:"publisher";a:4:{s:5:"@type";s:12:"Organization";s:3:"@id";s:43:"https://www-staging.nowrx.com/#organization";s:4:"name";s:14:"NowRx Pharmacy";s:4:"logo";a:4:{s:5:"@type";s:11:"ImageObject";s:3:"url";s:67:"http://nowrx.com/wp-content/uploads/2019/12/NowRx-Schema-Upload.png";s:5:"width";i:600;s:6:"height";i:60;}}s:6:"author";a:4:{s:5:"@type";s:6:"Person";s:4:"name";s:10:"Phil Rossi";s:3:"url";s:47:"https://www-staging.nowrx.com/blog/author/phil/";s:5:"image";a:4:{s:5:"@type";s:11:"ImageObject";s:3:"url";s:78:"https://www-staging.nowrx.com/wp-content/uploads/2020/02/WordPress-Image-1.png";s:6:"height";i:96;s:5:"width";i:96;}}}'),
(269, 621, '_schema_json_timestamp', '1598461658'),
(270, 622, '_wp_page_template', 'default'),
(271, 654, '_edit_last', '1'),
(272, 654, '_wp_page_template', 'page-pricing.php'),
(273, 655, '_wp_attached_file', '2020/09/logo.svg'),
(274, 656, '_wp_attached_file', '2020/09/hero-home.jpg'),
(275, 656, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:2218;s:6:"height";i:1282;s:4:"file";s:21:"2020/09/hero-home.jpg";s:5:"sizes";a:8:{s:6:"medium";a:4:{s:4:"file";s:21:"hero-home-250x144.jpg";s:5:"width";i:250;s:6:"height";i:144;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:21:"hero-home-700x405.jpg";s:5:"width";i:700;s:6:"height";i:405;s:9:"mime-type";s:10:"image/jpeg";}s:9:"thumbnail";a:4:{s:4:"file";s:21:"hero-home-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:21:"hero-home-768x444.jpg";s:5:"width";i:768;s:6:"height";i:444;s:9:"mime-type";s:10:"image/jpeg";}s:9:"1536x1536";a:4:{s:4:"file";s:22:"hero-home-1536x888.jpg";s:5:"width";i:1536;s:6:"height";i:888;s:9:"mime-type";s:10:"image/jpeg";}s:9:"2048x2048";a:4:{s:4:"file";s:23:"hero-home-2048x1184.jpg";s:5:"width";i:2048;s:6:"height";i:1184;s:9:"mime-type";s:10:"image/jpeg";}s:5:"small";a:4:{s:4:"file";s:20:"hero-home-120x69.jpg";s:5:"width";i:120;s:6:"height";i:69;s:9:"mime-type";s:10:"image/jpeg";}s:11:"custom-size";a:4:{s:4:"file";s:21:"hero-home-700x200.jpg";s:5:"width";i:700;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(276, 659, '_edit_lock', '1662922744:1') ;

#
# End of data contents of table `wp_postmeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_posts`
#

DROP TABLE IF EXISTS `wp_posts`;


#
# Table structure of table `wp_posts`
#

CREATE TABLE `wp_posts` (
  `ID` bigint unsigned NOT NULL AUTO_INCREMENT,
  `post_author` bigint unsigned NOT NULL DEFAULT '0',
  `post_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_title` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_excerpt` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_status` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'publish',
  `comment_status` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'open',
  `ping_status` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'open',
  `post_password` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `post_name` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `to_ping` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `pinged` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content_filtered` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_parent` bigint unsigned NOT NULL DEFAULT '0',
  `guid` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `menu_order` int NOT NULL DEFAULT '0',
  `post_type` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'post',
  `post_mime_type` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_count` bigint NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `post_name` (`post_name`(191)),
  KEY `type_status_date` (`post_type`,`post_status`,`post_date`,`ID`),
  KEY `post_parent` (`post_parent`),
  KEY `post_author` (`post_author`)
) ENGINE=InnoDB AUTO_INCREMENT=661 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_posts`
#
INSERT INTO `wp_posts` ( `ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(1, 1, '2020-09-21 21:03:25', '2020-09-21 21:03:25', '<!-- wp:paragraph -->\n<p>Welcome to WordPress. This is your first post. Edit or delete it, then start writing!</p>\n<!-- /wp:paragraph -->', 'Hello world!', '', 'publish', 'open', 'open', '', 'hello-world', '', '', '2020-09-21 21:03:25', '2020-09-21 21:03:25', '', 0, 'http://localhost:8888/dev2/?p=1', 0, 'post', '', 1),
(2, 1, '2020-09-21 21:03:25', '2020-09-21 21:03:25', '<!-- wp:paragraph -->\n<p>This is an example page. It\'s different from a blog post because it will stay in one place and will show up in your site navigation (in most themes). Most people start with an About page that introduces them to potential site visitors. It might say something like this:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:quote -->\n<blockquote class="wp-block-quote"><p>Hi there! I\'m a bike messenger by day, aspiring actor by night, and this is my website. I live in Los Angeles, have a great dog named Jack, and I like pi&#241;a coladas. (And gettin\' caught in the rain.)</p></blockquote>\n<!-- /wp:quote -->\n\n<!-- wp:paragraph -->\n<p>...or something like this:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:quote -->\n<blockquote class="wp-block-quote"><p>The XYZ Doohickey Company was founded in 1971, and has been providing quality doohickeys to the public ever since. Located in Gotham City, XYZ employs over 2,000 people and does all kinds of awesome things for the Gotham community.</p></blockquote>\n<!-- /wp:quote -->\n\n<!-- wp:paragraph -->\n<p>As a new WordPress user, you should go to <a href="http://localhost:8888/dev2/wp-admin/">your dashboard</a> to delete this page and create new pages for your content. Have fun!</p>\n<!-- /wp:paragraph -->', 'Sample Page', '', 'publish', 'closed', 'open', '', 'sample-page', '', '', '2020-09-21 21:03:25', '2020-09-21 21:03:25', '', 0, 'http://localhost:8888/dev2/?page_id=2', 0, 'page', '', 0),
(3, 1, '2020-09-21 21:03:25', '2020-09-21 21:03:25', '<!-- wp:heading --><h2>Who we are</h2><!-- /wp:heading --><!-- wp:paragraph --><p>Our website address is: http://localhost:8888/dev2.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>What personal data we collect and why we collect it</h2><!-- /wp:heading --><!-- wp:heading {"level":3} --><h3>Comments</h3><!-- /wp:heading --><!-- wp:paragraph --><p>When visitors leave comments on the site we collect the data shown in the comments form, and also the visitor&#8217;s IP address and browser user agent string to help spam detection.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>An anonymized string created from your email address (also called a hash) may be provided to the Gravatar service to see if you are using it. The Gravatar service privacy policy is available here: https://automattic.com/privacy/. After approval of your comment, your profile picture is visible to the public in the context of your comment.</p><!-- /wp:paragraph --><!-- wp:heading {"level":3} --><h3>Media</h3><!-- /wp:heading --><!-- wp:paragraph --><p>If you upload images to the website, you should avoid uploading images with embedded location data (EXIF GPS) included. Visitors to the website can download and extract any location data from images on the website.</p><!-- /wp:paragraph --><!-- wp:heading {"level":3} --><h3>Contact forms</h3><!-- /wp:heading --><!-- wp:heading {"level":3} --><h3>Cookies</h3><!-- /wp:heading --><!-- wp:paragraph --><p>If you leave a comment on our site you may opt-in to saving your name, email address and website in cookies. These are for your convenience so that you do not have to fill in your details again when you leave another comment. These cookies will last for one year.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>If you visit our login page, we will set a temporary cookie to determine if your browser accepts cookies. This cookie contains no personal data and is discarded when you close your browser.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>When you log in, we will also set up several cookies to save your login information and your screen display choices. Login cookies last for two days, and screen options cookies last for a year. If you select &quot;Remember Me&quot;, your login will persist for two weeks. If you log out of your account, the login cookies will be removed.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>If you edit or publish an article, an additional cookie will be saved in your browser. This cookie includes no personal data and simply indicates the post ID of the article you just edited. It expires after 1 day.</p><!-- /wp:paragraph --><!-- wp:heading {"level":3} --><h3>Embedded content from other websites</h3><!-- /wp:heading --><!-- wp:paragraph --><p>Articles on this site may include embedded content (e.g. videos, images, articles, etc.). Embedded content from other websites behaves in the exact same way as if the visitor has visited the other website.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>These websites may collect data about you, use cookies, embed additional third-party tracking, and monitor your interaction with that embedded content, including tracking your interaction with the embedded content if you have an account and are logged in to that website.</p><!-- /wp:paragraph --><!-- wp:heading {"level":3} --><h3>Analytics</h3><!-- /wp:heading --><!-- wp:heading --><h2>Who we share your data with</h2><!-- /wp:heading --><!-- wp:heading --><h2>How long we retain your data</h2><!-- /wp:heading --><!-- wp:paragraph --><p>If you leave a comment, the comment and its metadata are retained indefinitely. This is so we can recognize and approve any follow-up comments automatically instead of holding them in a moderation queue.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>For users that register on our website (if any), we also store the personal information they provide in their user profile. All users can see, edit, or delete their personal information at any time (except they cannot change their username). Website administrators can also see and edit that information.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>What rights you have over your data</h2><!-- /wp:heading --><!-- wp:paragraph --><p>If you have an account on this site, or have left comments, you can request to receive an exported file of the personal data we hold about you, including any data you have provided to us. You can also request that we erase any personal data we hold about you. This does not include any data we are obliged to keep for administrative, legal, or security purposes.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Where we send your data</h2><!-- /wp:heading --><!-- wp:paragraph --><p>Visitor comments may be checked through an automated spam detection service.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Your contact information</h2><!-- /wp:heading --><!-- wp:heading --><h2>Additional information</h2><!-- /wp:heading --><!-- wp:heading {"level":3} --><h3>How we protect your data</h3><!-- /wp:heading --><!-- wp:heading {"level":3} --><h3>What data breach procedures we have in place</h3><!-- /wp:heading --><!-- wp:heading {"level":3} --><h3>What third parties we receive data from</h3><!-- /wp:heading --><!-- wp:heading {"level":3} --><h3>What automated decision making and/or profiling we do with user data</h3><!-- /wp:heading --><!-- wp:heading {"level":3} --><h3>Industry regulatory disclosure requirements</h3><!-- /wp:heading -->', 'Privacy Policy', '', 'draft', 'closed', 'open', '', 'privacy-policy', '', '', '2020-09-21 21:03:25', '2020-09-21 21:03:25', '', 0, 'http://localhost:8888/dev2/?page_id=3', 0, 'page', '', 0),
(6, 2, '2020-09-01 22:46:18', '2020-09-01 22:46:18', '<!-- wp:paragraph -->\n<p>Welcome to WordPress. This is your first post. Edit or delete it, then start writing!</p>\n<!-- /wp:paragraph -->', 'Hello world!', '', 'publish', 'open', 'open', '', 'hello-world-2', '', '', '2020-09-01 22:46:18', '2020-09-01 22:46:18', '', 0, 'http://localhost:8888/dev/?p=1', 0, 'post', '', 1),
(8, 1, '2020-09-01 22:46:18', '2020-09-01 22:46:18', '<!-- wp:heading --><h2>Who we are</h2><!-- /wp:heading --><!-- wp:paragraph --><p>Our website address is: http://localhost:8888/dev.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>What personal data we collect and why we collect it</h2><!-- /wp:heading --><!-- wp:heading {"level":3} --><h3>Comments</h3><!-- /wp:heading --><!-- wp:paragraph --><p>When visitors leave comments on the site we collect the data shown in the comments form, and also the visitor&#8217;s IP address and browser user agent string to help spam detection.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>An anonymized string created from your email address (also called a hash) may be provided to the Gravatar service to see if you are using it. The Gravatar service privacy policy is available here: https://automattic.com/privacy/. After approval of your comment, your profile picture is visible to the public in the context of your comment.</p><!-- /wp:paragraph --><!-- wp:heading {"level":3} --><h3>Media</h3><!-- /wp:heading --><!-- wp:paragraph --><p>If you upload images to the website, you should avoid uploading images with embedded location data (EXIF GPS) included. Visitors to the website can download and extract any location data from images on the website.</p><!-- /wp:paragraph --><!-- wp:heading {"level":3} --><h3>Contact forms</h3><!-- /wp:heading --><!-- wp:heading {"level":3} --><h3>Cookies</h3><!-- /wp:heading --><!-- wp:paragraph --><p>If you leave a comment on our site you may opt-in to saving your name, email address and website in cookies. These are for your convenience so that you do not have to fill in your details again when you leave another comment. These cookies will last for one year.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>If you visit our login page, we will set a temporary cookie to determine if your browser accepts cookies. This cookie contains no personal data and is discarded when you close your browser.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>When you log in, we will also set up several cookies to save your login information and your screen display choices. Login cookies last for two days, and screen options cookies last for a year. If you select &quot;Remember Me&quot;, your login will persist for two weeks. If you log out of your account, the login cookies will be removed.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>If you edit or publish an article, an additional cookie will be saved in your browser. This cookie includes no personal data and simply indicates the post ID of the article you just edited. It expires after 1 day.</p><!-- /wp:paragraph --><!-- wp:heading {"level":3} --><h3>Embedded content from other websites</h3><!-- /wp:heading --><!-- wp:paragraph --><p>Articles on this site may include embedded content (e.g. videos, images, articles, etc.). Embedded content from other websites behaves in the exact same way as if the visitor has visited the other website.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>These websites may collect data about you, use cookies, embed additional third-party tracking, and monitor your interaction with that embedded content, including tracking your interaction with the embedded content if you have an account and are logged in to that website.</p><!-- /wp:paragraph --><!-- wp:heading {"level":3} --><h3>Analytics</h3><!-- /wp:heading --><!-- wp:heading --><h2>Who we share your data with</h2><!-- /wp:heading --><!-- wp:heading --><h2>How long we retain your data</h2><!-- /wp:heading --><!-- wp:paragraph --><p>If you leave a comment, the comment and its metadata are retained indefinitely. This is so we can recognize and approve any follow-up comments automatically instead of holding them in a moderation queue.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>For users that register on our website (if any), we also store the personal information they provide in their user profile. All users can see, edit, or delete their personal information at any time (except they cannot change their username). Website administrators can also see and edit that information.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>What rights you have over your data</h2><!-- /wp:heading --><!-- wp:paragraph --><p>If you have an account on this site, or have left comments, you can request to receive an exported file of the personal data we hold about you, including any data you have provided to us. You can also request that we erase any personal data we hold about you. This does not include any data we are obliged to keep for administrative, legal, or security purposes.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Where we send your data</h2><!-- /wp:heading --><!-- wp:paragraph --><p>Visitor comments may be checked through an automated spam detection service.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Your contact information</h2><!-- /wp:heading --><!-- wp:heading --><h2>Additional information</h2><!-- /wp:heading --><!-- wp:heading {"level":3} --><h3>How we protect your data</h3><!-- /wp:heading --><!-- wp:heading {"level":3} --><h3>What data breach procedures we have in place</h3><!-- /wp:heading --><!-- wp:heading {"level":3} --><h3>What third parties we receive data from</h3><!-- /wp:heading --><!-- wp:heading {"level":3} --><h3>What automated decision making and/or profiling we do with user data</h3><!-- /wp:heading --><!-- wp:heading {"level":3} --><h3>Industry regulatory disclosure requirements</h3><!-- /wp:heading -->', 'Privacy Policy', '', 'draft', 'closed', 'open', '', 'privacy-policy', '', '', '2020-09-01 22:46:18', '2020-09-01 22:46:18', '', 0, 'http://localhost:8888/dev/?page_id=3', 0, 'page', '', 0),
(9, 3, '2019-09-05 04:45:54', '2019-09-05 04:45:54', '<!-- wp:heading -->\n<p><strong>I. Introduction.</strong>NowRx, Inc. (“NowRx”, “we”, “us”, or “our”) operates the website located at www.nowrx.com and other related websites and mobile applications with links to this Privacy Policy (collectively, the “Site”). Through the Site, we operate an online service enabling members (“Members”) to receive telehealth services from various healthcare providers (the “Services”). We developed this privacy policy (“Privacy Policy”) to explain how we collect, use, and disclose information from and/or about you when you use the Site or the Services.</p>\n<p>THE SITE WILL BE COLLECTING AND TRANSMITTING PERSONAL, MEDICAL AND HEALTH-RELATED INFORMATION ABOUT YOU. BY USING THE SITE, YOU AGREE THAT WE CAN COLLECT AND USE YOUR PERSONAL AND OTHER INFORMATION AS DESCRIBED IN THIS PRIVACY POLICY. IF YOU DO NOT AGREE, PLEASE DO NOT USE THE SITE.</p>\n<p><strong>II. Important Definitions.</strong>When we use the term “Personal Information” in this Privacy Policy, we mean information about you that is personally identifiable to you, such as your contact information (e.g., name, address, email address, or telephone number), personally identifiable health or medical information (“Health Information”), and any other non-public information that is associated with such information (collectively, “Personal Information”). When we use the term “De-Identified Information”, we mean information that is neither used nor intended to be used to personally identify an individual. Lastly, when we use the term “Cookies”, we mean the small pieces of information that a Site sends to your browser while you are viewing a website.</p>\n<p><strong>III. Questions.</strong> If you have questions or concerns about this Privacy Policy, please contact us by sending an email to support@nowrx.com.</p>\n<p><strong>IV. HIPAA.</strong>Our privacy practices are intended to comply with the Health Insurance Portability and Accountability Act (“<strong>HIPAA</strong>“). We will maintain the privacy of your Health Information as required by HIPAA and the regulations promulgated under that Act. We encourage you to review our Notice of Privacy Practices, which describes how health we may use and disclose your Health Information.</p>\n<p><strong>V. Children under age 18.</strong>We do not knowingly allow individuals under the age 18 to create Accounts that allow access to our Site.</p>\n<p><strong>VI. The Personal information we collect or maintain may include:</strong></p>\n<ul>\n<li>Your name, age, email address, username, password, and other registration information</li>\n<li>Health Information that you provide us, which may include information or records relating to your medical or health history, health status and laboratory testing results, diagnostic images, and other health related information</li>\n<li>Health information about you prepared by the health care provider(s) who provide the Services through the Site such as medical records, treatment and examination notes, and other health related information</li>\n<li>Billing information that you provide us, such as credit card information</li>\n<li>Information about the computer or mobile device you are using, such as what Internet browser you use, the kind of computer or mobile device you use, and other information about how you use the Site</li>\n<li>Other information you input into the Site or related services</li>\n</ul>\n<p><strong>VII. We may use your Personal Information for the following purposes (subject to applicable legal restrictions):</strong></p>\n<ul>\n<li>To provide you with the Services</li>\n<li>To improve the quality of healthcare through the performance of quality reviews and similar activities</li>\n<li>To create De-identified Information such as aggregate statistics relating to the use of the Service</li>\n<li>To notify you when Site updates are available,</li>\n<li>To market and promote the Site and the Services to you</li>\n<li>To fulfill any other purpose for which you provide us Personal Information</li>\n<li>For any other purpose for which you give us authorization</li>\n</ul>\n<p><strong>VIII. We may also disclose Personal Information that we collect or you provide (subject to applicable legal restrictions):</strong></p>\n<ul>\n<li>To our subsidiaries and affiliates.</li>\n<li>To contractors, service providers and other third parties we use to support our business and who are bound by contractual obligations to keep personal information confidential and use it only for the purposes for which we disclose it to them.</li>\n<li>As required by law, which can include providing information as required by a court order.</li>\n<li>When we believe in good faith that disclosure is necessary to protect your safety or the safety of others, to protect our rights, to investigate fraud, or to respond to a government request.</li>\n<li>To a buyer or other successor in the event of a merger, divestiture, restructuring, reorganization, dissolution or other sale or transfer of some or all of NowRx’s assets, whether as a going concern or as part of bankruptcy, liquidation or similar proceeding, in which Personal Information maintained by the Site is among the assets transferred.</li>\n<li>For any other purpose disclosed by us when you provide the information.</li>\n</ul>\n<p><strong>IX. </strong><strong>Information We Collect via Technology.</strong>As you use the Site or the Service, certain information may be passively collected by Cookies, navigational data like Uniform Resource Locators (URLs) and third party tracking services, including:</p>\n<ul>\n<li>Site Activity Information. We may keep track of some of the actions you take on the Site, such as the content of searches you perform on the Site.</li>\n<li>Access Device and Browser Information. When you access the Site from a computer or other device, we may collect anonymous information from that device, such as your Internet protocol address, browser type, connection speed and access times (collectively, “Anonymous Information”).</li>\n<li>We may use both session Cookies (which expire once you close your web browser) and persistent Cookies to make the Site and Service easier to use, to make our advertising better, and to protect both you and NowRx. You can instruct your browser, by changing its options, to stop accepting Cookies or to prompt you before accepting a Cookie from the websites you visit. If you do not accept Cookies, however, you will not be able to stay logged in to the Site. We presently do not honor “Do Not Track” requests across all part of our Site.</li>\n<li>Real-Time Location. Certain features of the Site use GPS technology to collect real-time information about the location of your device so that the Site can connect you to a health care provider who is licensed or authorized to provide services in the state where you are located.</li>\n<li>Mobile Services. We may also collect non-personal information from your mobile device or computer. This information is generally used to help us deliver the most relevant information to you. Examples of information that may be collected and used include how you use the application(s) and and information about the type of device or computer you use. In addition, in the event our application(s) crashes on your mobile device we will receive information about your mobile device model software version and device carrier, which allows us to identify and fix bugs and otherwise improve the performance of our application(s).</li>\n<li>Google Analytics. We use Google Analytics to help analyze how users use the Site. Google Analytics uses Cookies to collect information such as how often users visit the Site, what pages they visit, and what other sites they used prior to coming to the Site. We use the information we get from Google Analytics only to improve our Site and Services. Google Analytics collects only the IP address assigned to you on the date you visit the Site, rather than your name or other personally identifying information. Although Google Analytics plants a persistent Cookie on your web browser to identify you as a unique user the next time you visit the Site, the Cookie cannot be used by anyone but Google. Google’s ability to use and share information collected by Google Analytics about your visits to the Site is restricted by the Google Analytics Terms of Use and the Google Privacy Policy.</li>\n</ul>\n<p><strong>X. De-Identified Information.</strong>We may use De-Identified Information created by us without restriction.</p>\n<p><strong>XI. Information You Share With Third Parties</strong>This Privacy Policy applies only to information we collect through the Site and in email, text and other electronic communications set through or in connection with the Site. This policy DOES NOT apply to information collected by any third party. When you click on links on the Site you may leave our site. We are not responsible for the privacy practices of other sites, and we encourage you to read their privacy statements.</p>\n<p><strong>XII. Modification of Information</strong>. Members will be able to update some of their information through the Site. Requests to modify any information may also be submitted directly to support@nowrx.com.</p>\n<p><strong>XIII. Limitations on Deletion of Information.</strong> You may request deletion of your Personal Information by us, but please note that we may be required (by law or otherwise) to keep this information and not delete it (or to keep this information for a certain time, in which case we will comply with your deletion request only after we have fulfilled such requirements). When we delete Personal Information, it will be deleted from the active database, but may remain in our archives and we may also retain Anonymous Information about your use of our Service. Once we disclose some of your Personal Information to third parties, we may not be able to access that Personal Information any longer and cannot force the deletion or modification of any such information by the parties to whom we have made those disclosures. After we delete Personal Information, we will retain De-Identified Data and will continue to use De-Identified Data as permitted under this Privacy Policy.</p>\n<p><strong>XIV. Steps we take to keep your information secure.</strong> We employ reasonable physical, electronic and managerial security methods to help protect against unauthorized access to Personal Information, such as encryption. But please be aware that no data transmission over the Internet or data storage facility can be guaranteed to be perfectly secure. As a result, while we try to protect your Personal Information, we cannot ensure or guarantee the security of any information you transmit to us, and you do so at your own risk.</p>\n<p><strong>XV. Report Violations.</strong>You should report any security violations to us by sending an email to <strong>support@nowrx.com.</strong></p>\n<p><strong>XVI. Changes to this Privacy Policy.</strong> We may change this Privacy Policy from time to time in the future. We will post any revised version of the Privacy Policy on this page. Continued use of our Service following notice of such changes will indicate your acknowledgement of such changes and agreement to be bound by the terms and conditions of such changes. By using the Site, you are agreeing to our collection, use and disposal of Personal Information and other data as described in this Privacy Policy, both as it exists now and as it is changed from time to time.</p>\n<!-- /wp:heading -->', 'Privacy Policy', '', 'publish', 'closed', 'open', '', 'privacy-policy-2', '', '', '2019-09-05 04:45:54', '2019-09-05 04:45:54', '', 0, 'http:/?page_id=3', 0, 'page', '', 0),
(10, 4, '2019-09-23 13:45:21', '2019-09-23 13:45:21', '', 'About Us', '', 'publish', 'closed', 'closed', '', 'about-us', '', '', '2019-09-23 13:45:21', '2019-09-23 13:45:21', '', 0, 'http://34.215.180.211/?page_id=8', 0, 'page', '', 0),
(11, 4, '2019-09-23 13:46:31', '2019-09-23 13:46:31', '', 'Blog', '', 'publish', 'closed', 'closed', '', 'blog', '', '', '2019-09-23 13:46:31', '2019-09-23 13:46:31', '', 0, 'http://34.215.180.211/?page_id=10', 0, 'page', '', 0),
(12, 4, '2019-09-23 13:45:33', '2019-09-23 13:45:33', '', 'Careers', '', 'publish', 'closed', 'closed', '', 'careers', '', '', '2019-09-23 13:45:33', '2019-09-23 13:45:33', '', 0, 'http://34.215.180.211/?page_id=12', 0, 'page', '', 0),
(14, 4, '2019-09-23 13:46:35', '2019-09-23 13:46:35', 'Give us a call from Monday to Saturday from 09:00 AM to 5:00 PM. Not an urgent matter? Send us an email!\n\n[hubspot type=form portal=5952677 id=c188dea2-9f48-4162-a31a-134e43424916]', 'Contact Us', '', 'publish', 'closed', 'closed', '', 'contact-us', '', '', '2019-09-23 13:46:35', '2019-09-23 13:46:35', '', 0, 'http://34.215.180.211/?page_id=14', 0, 'page', '', 0),
(16, 4, '2019-09-23 13:46:39', '2019-09-23 13:46:39', '', 'NowRx For Doctors', '', 'publish', 'closed', 'closed', '', 'for-doctors', '', '', '2019-09-23 13:46:39', '2019-09-23 13:46:39', '', 0, 'http://34.215.180.211/?page_id=16', 0, 'page', '', 0),
(18, 4, '2019-09-23 13:46:43', '2019-09-23 13:46:43', '', 'Get Started Today', '', 'publish', 'closed', 'closed', '', 'get-started', '', '', '2019-09-23 13:46:43', '2019-09-23 13:46:43', '', 0, 'http://34.215.180.211/?page_id=18', 0, 'page', '', 0),
(20, 4, '2019-09-23 13:46:46', '2019-09-23 13:46:46', '', 'How It Works', '', 'publish', 'closed', 'closed', '', 'how-it-works', '', '', '2019-09-23 13:46:46', '2019-09-23 13:46:46', '', 0, 'http://34.215.180.211/?page_id=20', 0, 'page', '', 0),
(22, 4, '2019-09-23 13:46:50', '2019-09-23 13:46:50', '', 'Locations', '', 'publish', 'closed', 'closed', '', 'locations', '', '', '2019-09-23 13:46:50', '2019-09-23 13:46:50', '', 0, 'http://34.215.180.211/?page_id=22', 0, 'page', '', 0),
(24, 4, '2019-09-23 13:46:54', '2019-09-23 13:46:54', 'jose', 'Press', '', 'publish', 'closed', 'closed', '', 'press', '', '', '2019-09-23 13:46:54', '2019-09-23 13:46:54', '', 0, 'http://34.215.180.211/?page_id=24', 0, 'page', '', 0),
(30, 4, '2019-09-24 12:53:40', '2019-09-24 12:53:40', '', 'Home', '', 'publish', 'closed', 'closed', '', 'home', '', '', '2019-09-24 12:53:40', '2019-09-24 12:53:40', '', 0, 'http://34.215.180.211/?page_id=30', 0, 'page', '', 0),
(46, 4, '2019-09-29 22:00:13', '2019-09-29 22:00:13', 'Contact thank you', 'Thank You', '', 'publish', 'closed', 'closed', '', 'thank-you', '', '', '2019-09-29 22:00:13', '2019-09-29 22:00:13', '', 14, 'http://34.215.180.211/?page_id=46', 0, 'page', '', 0),
(56, 4, '2019-10-13 01:54:10', '2019-10-13 01:54:10', 'Under the Health Insurance Portability and Accountability Act of 1996 (“HIPAA”), NowRx (“We” or“Us”) is required to provide you with a Notice of Privacy Practices that describes how we may use your information for treatment, payment and other purposes that details your rights regarding the privacy of your health and medical information.\n\nEffective Date: January 1, 2019\n\n<strong>THIS NOTICE DESCRIBES HOW MEDICAL INFORMATION ABOUT YOU MAY BE USED AND DISCLOSED AND HOW YOU CAN GET ACCESS TO THIS INFORMATION.</strong>\n\nPLEASE REVIEW IT CAREFULLY.\n\n<strong>OUR DUTY TO PROTECT YOUR PRIVACY:</strong>\n\nWe are required by law to:\n\nMaintain the privacy of protected health information\n\nGive you this notice of our legal duties and privacy practices regarding health information about you\n\nFollow the terms of our notice that is currently in effect\n\n<strong>HOW WE MAY USE AND DISCLOSE HEALTH INFORMATION:</strong>\n\nThe following describes the ways we may use and disclose health information that identifies you (“Protected Health Information” or “PHI”). Except for the purposes described below, we will use and disclose Protected Health Information only with your written permission. You may revoke such permission at any time by writing to our company Privacy Officer.\n\nFor Treatment. We may use and disclose PHI for your treatment and to provide you with treatment-related health care services. For example, we may disclose PHI to doctors, nurses, pharmacists, technicians, or other personnel, including people outside our office, who are involved in your medical care and need the information to provide you with medical care.\n\nFor Payment. We may use and disclose Protected Health Information so that we or others may bill and receive payment from you, an insurance company or a third party for the treatment and services you received. For example, we may give your health plan information about you so that they will pay for your treatment.\n\nFor Health Care Operations. We may use and disclose PHI for health care operations purposes. These uses and disclosures are necessary to make sure that all of our patients receive quality care and to operate and manage our office. We also may share information with other entities that have a relationship with you (for example, your health plan) for their health care operation activities.\n\nReminders, Treatment Alternatives and Health Related Benefits and Services. We may use and disclose PHI to contact you to remind you that you have a prescription with us. We also may use and disclose PHI to tell you about treatment alternatives or health-related benefits and services that may be of interest to you.\n\nIndividuals Involved in Your Care or Payment for Your Care. When appropriate, we may share Protected Health Information with a person who is involved in your medical care or payment for your care, such as your family or a close friend. We also may notify your family about your location or general condition or disclose such information to an entity assisting in a disaster relief effort.\n\nResearch. Under certain circumstances, we may use and disclose PHI for research. For example, a research project may involve comparing the health of patients who received one medication to those who received another, for the same condition. Before we use or disclose PHI for research, the project must have been approved by an institutional review board or privacy board that has reviewed the research proposal and established protocols to ensure the privacy of your information.\n\n<strong>SPECIAL SITUATIONS:</strong>\n\nAs Required by Law. We will disclose Protected Health Information when required to do so by international, federal, state or local law.\n\nTo Avert a Serious Threat to Health or Safety. We may use and disclose PHI when necessary to prevent a serious threat to your health and safety or the health and safety of the public or another person. Disclosures, however, will be made only to someone who maybe able to help prevent the threat.\n\nBusiness Associates. We may disclose Protected Health Information to our business associates that perform functions on our behalf or provide us with services if the information is necessary for such functions or services. All of our business associates are obligated to protect the privacy of your information and are not allowed to use or disclose any information other than as specified in our contract.\n\nOrgan or Tissue Donation. If you are an organ donor, we may use or release PHI to organizations that handle organ procurement or other entities engaged in procurement, banking or transportation of organs, eyes or tissues to facilitate organ, eye or tissue donation and transplantation.\n\nMilitary and Veterans. If you are a member of the armed forces, we may release Protected Health Information as required by military command authorities. We also may release PHI to the appropriate foreign military authority if you are a member of a foreign military.\n\nWorker’s Compensation. We may release PHI for workers’ compensation or similar programs. These programs provide benefits for work-related injuries or illness.\n\nPublic Health Risks. We may disclose Protected Health Information for public health activities. These activities generally include disclosures to prevent or control disease, injury or disability; report births and deaths; report child abuse or neglect; report reactions to medications or problems with products; notify people of recalls of products they may be using; a person who may have been exposed to a disease or may be at risk for contracting or spreading a disease or condition; and the appropriate government authority if we believe a patient has been the victim of abuse, neglect or domestic violence. We will only make this disclosure if you agree or when required or authorized by law.\n\nHealth Oversight Activities. We may disclose PHI to a health oversight agency for activities authorized by law. These oversight activities include, for example, audits, investigations, inspections, and licensure. These activities are necessary for the government to monitor the health care system, government programs, and compliance with civil rights laws.\n\nData Breach Notification Purposes. We may use or disclose your Protected Health Information to provide legally required notices of unauthorized access to or disclosure of your health information.\n\nLawsuits and Disputes. If you are involved in a lawsuit or a dispute, we may disclose PHI in response to a court or administrative order. We also may disclose PHI in response to a subpoena, discovery request, or other lawful process by someone else involved in the dispute, but only if efforts have been made to tell you about there quest or to obtain an order protecting the information requested.\n\nLaw Enforcement. We may release Protected Health Information if asked by a law enforcement official if the information is: (1) in response to a court order, subpoena, warrant, summons or similar process; (2) limited information to identify or locate a suspect, fugitive, material witness, or missing person; (3) about the victim of a crime even if, under certain very limited circumstances, we are unable to obtain the person’s agreement; (4) about a death we believe may be the result of criminal conduct; (5) about criminal conduct on our premises; and (6) in an emergency to report a crime, the location of the crime or victims, or the identity, description or location of the person who committed the crime.\n\nCoroners, Medical Examiners, and Funeral Directors. We may release PHI to a coroner or medical examiner. This may be necessary, for example, to identify a deceased person or determine the cause of death. We also may release PHI to funeral directors as necessary for their duties.\n\nNational Security and Intelligence Activities. We may release PHI to authorized federal officials for intelligence, counter-intelligence, and other national security activities authorized by law.\n\nProtective Services for the President and Others. We may disclose PHI to authorized federal officials so they may provide protection to the President, other authorized persons or foreign heads of state or to conduct special investigations.\n\nInmates or Individuals in Custody. If you are an inmate of a correctional institution or under the custody of a law enforcement official, we may release PHI to the correctional institution or law enforcement official. This release would be if necessary:(1) for the institution to provide you with health care; (2) to protect your health and safety or the health and safety of others; or (3) the safety and security of the correctional institution.\n\n<strong>USES AND DISCLOSURES THAT REQUIRE US TO GIVE YOU AN OPPORTUNITY TO OBJECT AND OPT OUT :</strong>\n\nIndividuals Involved in Your Care or Payment for Your Care. Unless you object, we may disclose to a member of your family, a relative, a close friend or any other person you identify, your Protected Health Information that directly relates to that person’s involvement in your health care. If you are unable to agree or object to such a disclosure, we may disclose such information as necessary if we determine that it is in your best interest based on our professional judgment.\n\nDisaster Relief. We may disclose your PHI to disaster relief organizations that seek your PHI to coordinate your care, or notify family and friends of your location or condition in a disaster. We will provide you with an opportunity to agree or object to such a disclosure whenever we practically can do so.\n\n<strong>YOUR WRITTEN AUTHORIZATION IS REQUIRED FOR OTHER USES AND DISCLOSURES:</strong>\n\nThe following uses and disclosures of your Protected Health Information will be made only with your written authorization:\n\nUses and disclosures of Protected Health Information for marketing purposes; and\n\nDisclosures that constitute a sale of your Protected Health Information\n\nOther uses and disclosures of Protected Health Information not covered by this Notice or the laws that apply to us will be made only with your written authorization. If you do give us an authorization, you may revoke it at any time by submitting a written revocation to our Privacy Officer and we will no longer disclose Protected Health Information under the authorization. But disclosure that we made in reliance on your authorization before you revoked it will not be affected by the revocation.\n\n<strong>YOUR RIGHTS:</strong>\n\nYou have the following rights regarding Health Information we have about you:\n\nRight to Inspect and Copy. You have a right to inspect and copy PHI that may be used to make decisions about your care or payment for your care. This includes medical and billing records. We have up to 30 days to make your PHI available to you and we may charge you a reasonable fee for the costs of copying, mailing or other supplies associated with your request. We may not charge you a fee if you need the information for a claim for benefits under the Social Security Act or any other state of federal needs-based benefit program. We may deny your request in certain limited circumstances. If we do deny your request, you have the right to have the denial reviewed by a licensed healthcare professional who was not directly involved in the denial of your request, and we will comply with the outcome of the review.\n\nRight to an Electronic Copy of PHI and/or Electronic Medical Records. If your Protected Health Information is maintained in an electronic format (known as an electronic medical record or an electronic health record), you have the right to request that an electronic copy of your record be given to you or transmitted to another individual or entity. We will make every effort to provide access to your Protected Health Information in the form or format you request, if it is readily producible in such form or format. If the PHI is not readily producible in the form or format you request your record will be provided in either our standard electronic format or if you do not want this form or format, a readable hard copy form. We may charge you a reasonable, cost-based fee for the labor associated with transmitting the electronic medical record.\n\nRight to Get Notice of a Breach. You have the right to be notified upon a breach of any of your unsecured Protected Health Information.\n\nRight to Amend. If you feel that PHI we have is incorrect or incomplete, you may ask us to amend the information. You have the right to request an amendment for as long as the information is kept by or for our office.\n\nRight to an Accounting of Disclosures. You have the right to request a list of certain disclosures we made of PHI for purposes other than treatment, payment and health care operations or for which you provided written authorization.\n\nRight to Request Restrictions. You have the right to request a restriction or limitation on the Protected Health Information we use or disclose for treatment, payment, or health care operations. You also have the right to request a limit on the PHI we disclose to someone involved in your care or the payment for your care, like a family member or friend. We are not required to agree to your request unless you are asking us to restrict the use and disclosure of your PHI to a health plan for payment or health care operation purposes and such information you wish to restrict pertains solely to a health care item or service for which you have paid us “out-of-pocket” in full. If we agree, we will comply with your request unless the information is needed to provide you with emergency treatment.\n\nOut-of-Pocket-Payments. If you paid out-of-pocket (or in other words, you have requested that we not bill your health plan) in full for a specific item or service, you have the right to ask that your Protected Health Information with respect to that item or service not be disclosed to a health plan for purposes of payment or healthcare operations, and we will honor that request.\n\nRight to Request Confidential Communications. You have the right to request that we communicate with you about medical matters in a certain way or at a certain location. For example, you can ask that we only contact you by mail or at work. Your request must specify how or where you wish to be contacted. We will accommodate reasonable requests.\n\nRight to a Paper Copy of This Notice. You have the right to a paper copy of this notice. You may ask us to give you a copy of this notice at any time. Even if you have agreed to receive this notice electronically, you are still entitled to a paper copy of this notice.\n\nWhere to Obtain Forms for Submitting Written Requests. You may obtain forms for submitting written requests by contacting the Privacy Officer at NowRx, 2224 Old Middlefield Way, Suite J, Mountain View, CA 94043 or by telephone at (650) 386-5761.\n\n<strong>CHANGES TO THIS NOTICE:</strong>\n\nWe reserve the right to change this notice and make the new notice apply to Protected Health Information we already have as well as any information we receive in the future. We will post a copy of our current notice at our office. The notice will contain the effective date on the first page, in the top right-hand corner.\n\n<strong>COMPLAINTS:</strong>\n\nIf you believe your privacy rights have been violated, you may file a complaint with our office or with the Secretary of the Department of Health and Human Services. To file a complaint with our office, contact NowRx, 2224 Old Middlefield Way, Suite J, Mountain View, CA 94043 or by telephone at (650) 386-5761. All complaints must be made in writing. You will not be penalized for filing a complaint.', 'Notice of Privacy Practices', '', 'publish', 'closed', 'closed', '', 'hipaa-privacy', '', '', '2019-10-13 01:54:10', '2019-10-13 01:54:10', '', 0, 'http://34.215.180.211/?page_id=56', 0, 'page', '', 0),
(65, 4, '2019-10-22 15:45:10', '2019-10-22 15:45:10', 'You can now invest in NowRx and take part in our journey as we continue to expand our business into other areas of California.\n\nNowRx has partnered with SeedInvest to raise money via equity crowdfunding, which means anyone can invest and join NowRx as we revolutionize pharmacy.\n\n<a href="https://www.nowrx.com/nowrx-offering-circular-series-b-preferred.pdf">View NowRx Offering Circular Series B Preferred PDF</a>', 'NowRx Offering Circular Series B Preferred', '', 'publish', 'closed', 'closed', '', 'nowrx-offering-circular-series-b-preferred-pdf', '', '', '2019-10-22 15:45:10', '2019-10-22 15:45:10', '', 0, 'http://www.nowrx.com/?page_id=65', 0, 'page', '', 0),
(159, 4, '2019-11-26 14:46:43', '2019-11-26 14:46:43', '&nbsp;\n\n<hr />\n<p class="text-small">If NowRx doesn\'t have an email on file, please email info@NowRx.com so we can update your customer profile. You may view the <a href="http://nowrx.com/wp-content/uploads/2020/01/TC.pdf" target="_blank" rel="noopener noreferrer">full list of terms and conditions for NowRx Referral Program Here.</a> Please note that no credits, cash, benefits, rewards, or coupons can be given for referring prescriptions paid for by Medicare/Medicaid.</p>', 'Refer Friends - Earn Money', '', 'publish', 'closed', 'closed', '', 'referral', '', '', '2019-11-26 14:46:43', '2019-11-26 14:46:43', '', 0, 'http://www.nowrx.com/?page_id=159', 0, 'page', '', 0),
(173, 3, '2019-12-06 18:06:08', '2019-12-06 18:06:08', 'Your referrals have been successfully submitted. They will receive an email shortly letting them know you have referred them to NowRx Pharmacy.\n\n<strong>What\'s next?</strong>\n<ol>\n 	<li>Follow up with your referrals to make sure they have a prescription filled through NowRx Pharmacy in the next 90 days.</li>\n 	<li>At the end of each month, we will count the number of referrals that have filled a prescription through NowRx Pharmacy.</li>\n 	<li>For each successful referral, we will deliver you a $20 Visa Gift Card.</li>\n</ol>\n&nbsp;\n\nYou can view the full list of Terms and Conditions for the <a href="#">NowRx Pharmacy Referral Program Here.</a>', 'Thank You', '', 'publish', 'closed', 'closed', '', 'thank-you', '', '', '2019-12-06 18:06:08', '2019-12-06 18:06:08', '', 0, 'http://nowrx.com/?page_id=173', 0, 'page', '', 0),
(286, 4, '2020-01-16 22:36:48', '2020-01-16 22:36:48', '', 'Frequently Asked Questions', '', 'publish', 'closed', 'closed', '', 'faqs', '', '', '2020-01-16 22:36:48', '2020-01-16 22:36:48', '', 0, 'http://www.nowrx.com/?page_id=286', 0, 'page', '', 0),
(493, 5, '2020-03-04 20:21:34', '2020-03-04 20:21:34', '', 'Common Cold and Flu Symptoms Have You Worried?', '', 'publish', 'closed', 'closed', '', 'common-cold-flu-symptoms', '', '', '2020-03-04 20:21:34', '2020-03-04 20:21:34', '', 0, 'http://nowrx.com/?page_id=493', 0, 'page', '', 0),
(621, 5, '2020-04-14 22:48:45', '2020-04-14 22:48:45', '', 'Test Page', '', 'publish', 'closed', 'closed', '', 'test-page', '', '', '2020-04-14 22:48:45', '2020-04-14 22:48:45', '', 0, 'http://nowrx.com/?page_id=621', 0, 'page', '', 0),
(622, 1, '2020-09-01 22:46:18', '2020-09-01 22:46:18', '<!-- wp:paragraph -->\n<p>This is an example page. It\'s different from a blog post because it will stay in one place and will show up in your site navigation (in most themes). Most people start with an About page that introduces them to potential site visitors. It might say something like this:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:quote -->\n<blockquote class="wp-block-quote"><p>Hi there! I\'m a bike messenger by day, aspiring actor by night, and this is my website. I live in Los Angeles, have a great dog named Jack, and I like pi&#241;a coladas. (And gettin\' caught in the rain.)</p></blockquote>\n<!-- /wp:quote -->\n\n<!-- wp:paragraph -->\n<p>...or something like this:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:quote -->\n<blockquote class="wp-block-quote"><p>The XYZ Doohickey Company was founded in 1971, and has been providing quality doohickeys to the public ever since. Located in Gotham City, XYZ employs over 2,000 people and does all kinds of awesome things for the Gotham community.</p></blockquote>\n<!-- /wp:quote -->\n\n<!-- wp:paragraph -->\n<p>As a new WordPress user, you should go to <a href="http://localhost:8888/dev/wp-admin/">your dashboard</a> to delete this page and create new pages for your content. Have fun!</p>\n<!-- /wp:paragraph -->', 'Sample Page', '', 'publish', 'closed', 'open', '', 'sample-page-2', '', '', '2020-09-01 22:46:18', '2020-09-01 22:46:18', '', 0, 'http://localhost:8888/dev/?page_id=2', 0, 'page', '', 0),
(654, 1, '2020-09-04 01:40:48', '2020-09-04 01:40:48', '', 'Pricing', '', 'publish', 'closed', 'closed', '', 'pricing', '', '', '2020-09-04 01:40:48', '2020-09-04 01:40:48', '', 0, 'http://localhost:8888/dev/?page_id=654', 0, 'page', '', 0),
(655, 1, '2020-09-21 23:20:19', '2020-09-21 23:20:19', '', 'logo', '', 'inherit', 'open', 'closed', '', 'logo', '', '', '2020-09-21 23:20:19', '2020-09-21 23:20:19', '', 0, 'http://localhost:8888/dev2/wp-content/uploads/2020/09/logo.svg', 0, 'attachment', 'image/svg+xml', 0),
(656, 1, '2020-09-21 23:29:07', '2020-09-21 23:29:07', '', 'hero-home', '', 'inherit', 'open', 'closed', '', 'hero-home', '', '', '2020-09-21 23:29:07', '2020-09-21 23:29:07', '', 0, 'http://localhost:8888/dev2/wp-content/uploads/2020/09/hero-home.jpg', 0, 'attachment', 'image/jpeg', 0) ;
INSERT INTO `wp_posts` ( `ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(657, 1, '2022-09-11 18:51:03', '2022-09-11 18:51:03', 'Content of the page', '404-locations', '', 'publish', 'close', 'close', '', '404-locations', '', '', '2022-09-11 18:51:03', '2022-09-11 18:51:03', '', 0, 'http://localhost:8888/dev2/404-locations/', 0, 'page', '', 0),
(658, 1, '2022-09-11 19:00:53', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'open', 'open', '', '', '', '', '2022-09-11 19:00:53', '0000-00-00 00:00:00', '', 0, 'http://wp-valet.test/?p=658', 0, 'post', '', 0),
(659, 1, '2022-09-11 19:01:21', '2022-09-11 19:01:21', '', 'BMI', '', 'publish', 'closed', 'closed', '', 'bmi', '', '', '2022-09-11 19:01:21', '2022-09-11 19:01:21', '', 0, 'http://wp-valet.test/?page_id=659', 0, 'page', '', 0),
(660, 1, '2022-09-11 19:01:21', '2022-09-11 19:01:21', '', 'BMI', '', 'inherit', 'closed', 'closed', '', '659-revision-v1', '', '', '2022-09-11 19:01:21', '2022-09-11 19:01:21', '', 659, 'http://wp-valet.test/?p=660', 0, 'revision', '', 0) ;

#
# End of data contents of table `wp_posts`
# --------------------------------------------------------



#
# Delete any existing table `wp_smackcsv_file_events`
#

DROP TABLE IF EXISTS `wp_smackcsv_file_events`;


#
# Table structure of table `wp_smackcsv_file_events`
#

CREATE TABLE `wp_smackcsv_file_events` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `file_name` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL,
  `mode` varchar(255) NOT NULL,
  `hash_key` varchar(255) NOT NULL,
  `total_rows` int NOT NULL,
  `lock` tinyint(1) DEFAULT '0',
  `progress` int DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3;


#
# Data contents of table `wp_smackcsv_file_events`
#
INSERT INTO `wp_smackcsv_file_events` ( `id`, `file_name`, `status`, `mode`, `hash_key`, `total_rows`, `lock`, `progress`) VALUES
(1, '1600722372_plugin-details.csv', 'Downloaded', '', '72694d75e6c01957c483314911905ce4', 7, 0, NULL) ;

#
# End of data contents of table `wp_smackcsv_file_events`
# --------------------------------------------------------



#
# Delete any existing table `wp_smackuci_events`
#

DROP TABLE IF EXISTS `wp_smackuci_events`;


#
# Table structure of table `wp_smackuci_events`
#

CREATE TABLE `wp_smackuci_events` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `revision` bigint NOT NULL DEFAULT '0',
  `name` varchar(255) DEFAULT NULL,
  `original_file_name` varchar(255) DEFAULT NULL,
  `friendly_name` varchar(255) DEFAULT NULL,
  `import_type` varchar(32) DEFAULT NULL,
  `filetype` text,
  `filepath` text,
  `eventKey` varchar(32) DEFAULT NULL,
  `registered_on` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `parent_node` varchar(255) DEFAULT NULL,
  `processing` tinyint(1) NOT NULL DEFAULT '0',
  `executing` tinyint(1) NOT NULL DEFAULT '0',
  `triggered` tinyint(1) NOT NULL DEFAULT '0',
  `event_started_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `count` bigint NOT NULL DEFAULT '0',
  `processed` bigint NOT NULL DEFAULT '0',
  `created` bigint NOT NULL DEFAULT '0',
  `updated` bigint NOT NULL DEFAULT '0',
  `skipped` bigint NOT NULL DEFAULT '0',
  `deleted` bigint NOT NULL DEFAULT '0',
  `is_terminated` tinyint(1) NOT NULL DEFAULT '0',
  `terminated_on` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `last_activity` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `siteid` int NOT NULL DEFAULT '1',
  `month` varchar(60) DEFAULT NULL,
  `year` varchar(60) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;


#
# Data contents of table `wp_smackuci_events`
#

#
# End of data contents of table `wp_smackuci_events`
# --------------------------------------------------------



#
# Delete any existing table `wp_term_relationships`
#

DROP TABLE IF EXISTS `wp_term_relationships`;


#
# Table structure of table `wp_term_relationships`
#

CREATE TABLE `wp_term_relationships` (
  `object_id` bigint unsigned NOT NULL DEFAULT '0',
  `term_taxonomy_id` bigint unsigned NOT NULL DEFAULT '0',
  `term_order` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`object_id`,`term_taxonomy_id`),
  KEY `term_taxonomy_id` (`term_taxonomy_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_term_relationships`
#
INSERT INTO `wp_term_relationships` ( `object_id`, `term_taxonomy_id`, `term_order`) VALUES
(1, 1, 0),
(6, 1, 0) ;

#
# End of data contents of table `wp_term_relationships`
# --------------------------------------------------------



#
# Delete any existing table `wp_term_taxonomy`
#

DROP TABLE IF EXISTS `wp_term_taxonomy`;


#
# Table structure of table `wp_term_taxonomy`
#

CREATE TABLE `wp_term_taxonomy` (
  `term_taxonomy_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint unsigned NOT NULL DEFAULT '0',
  `taxonomy` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `description` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `parent` bigint unsigned NOT NULL DEFAULT '0',
  `count` bigint NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_taxonomy_id`),
  UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`),
  KEY `taxonomy` (`taxonomy`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_term_taxonomy`
#
INSERT INTO `wp_term_taxonomy` ( `term_taxonomy_id`, `term_id`, `taxonomy`, `description`, `parent`, `count`) VALUES
(1, 1, 'category', '', 0, 2) ;

#
# End of data contents of table `wp_term_taxonomy`
# --------------------------------------------------------



#
# Delete any existing table `wp_termmeta`
#

DROP TABLE IF EXISTS `wp_termmeta`;


#
# Table structure of table `wp_termmeta`
#

CREATE TABLE `wp_termmeta` (
  `meta_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`meta_id`),
  KEY `term_id` (`term_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_termmeta`
#

#
# End of data contents of table `wp_termmeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_terms`
#

DROP TABLE IF EXISTS `wp_terms`;


#
# Table structure of table `wp_terms`
#

CREATE TABLE `wp_terms` (
  `term_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `slug` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `term_group` bigint NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_id`),
  KEY `slug` (`slug`(191)),
  KEY `name` (`name`(191))
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_terms`
#
INSERT INTO `wp_terms` ( `term_id`, `name`, `slug`, `term_group`) VALUES
(1, 'Uncategorized', 'uncategorized', 0) ;

#
# End of data contents of table `wp_terms`
# --------------------------------------------------------



#
# Delete any existing table `wp_ultimate_csv_importer_acf_fields`
#

DROP TABLE IF EXISTS `wp_ultimate_csv_importer_acf_fields`;


#
# Table structure of table `wp_ultimate_csv_importer_acf_fields`
#

CREATE TABLE `wp_ultimate_csv_importer_acf_fields` (
  `id` int NOT NULL AUTO_INCREMENT,
  `groupId` varchar(100) NOT NULL,
  `fieldId` varchar(100) NOT NULL,
  `fieldLabel` varchar(100) NOT NULL,
  `fieldName` varchar(100) NOT NULL,
  `fieldType` varchar(60) NOT NULL,
  `fdOption` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;


#
# Data contents of table `wp_ultimate_csv_importer_acf_fields`
#

#
# End of data contents of table `wp_ultimate_csv_importer_acf_fields`
# --------------------------------------------------------



#
# Delete any existing table `wp_ultimate_csv_importer_mappingtemplate`
#

DROP TABLE IF EXISTS `wp_ultimate_csv_importer_mappingtemplate`;


#
# Table structure of table `wp_ultimate_csv_importer_mappingtemplate`
#

CREATE TABLE `wp_ultimate_csv_importer_mappingtemplate` (
  `id` int NOT NULL AUTO_INCREMENT,
  `templatename` varchar(250) NOT NULL,
  `mapping` blob NOT NULL,
  `createdtime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `deleted` int DEFAULT '0',
  `templateused` int DEFAULT '0',
  `mapping_type` varchar(30) DEFAULT NULL,
  `module` varchar(50) DEFAULT NULL,
  `csvname` varchar(250) DEFAULT NULL,
  `eventKey` varchar(60) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;


#
# Data contents of table `wp_ultimate_csv_importer_mappingtemplate`
#

#
# End of data contents of table `wp_ultimate_csv_importer_mappingtemplate`
# --------------------------------------------------------



#
# Delete any existing table `wp_ultimate_csv_importer_media`
#

DROP TABLE IF EXISTS `wp_ultimate_csv_importer_media`;


#
# Table structure of table `wp_ultimate_csv_importer_media`
#

CREATE TABLE `wp_ultimate_csv_importer_media` (
  `post_id` int DEFAULT NULL,
  `attach_id` int NOT NULL,
  `image_url` varchar(255) NOT NULL,
  `hash_key` varchar(255) NOT NULL,
  `status` varchar(255) DEFAULT 'pending',
  `module` varchar(255) DEFAULT NULL,
  `image_type` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;


#
# Data contents of table `wp_ultimate_csv_importer_media`
#

#
# End of data contents of table `wp_ultimate_csv_importer_media`
# --------------------------------------------------------



#
# Delete any existing table `wp_ultimate_csv_importer_shortcode_manager`
#

DROP TABLE IF EXISTS `wp_ultimate_csv_importer_shortcode_manager`;


#
# Table structure of table `wp_ultimate_csv_importer_shortcode_manager`
#

CREATE TABLE `wp_ultimate_csv_importer_shortcode_manager` (
  `post_id` int DEFAULT NULL,
  `image_shortcode` varchar(255) NOT NULL,
  `original_image` varchar(255) NOT NULL,
  `hash_key` varchar(255) NOT NULL,
  `status` varchar(255) DEFAULT 'pending'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;


#
# Data contents of table `wp_ultimate_csv_importer_shortcode_manager`
#

#
# End of data contents of table `wp_ultimate_csv_importer_shortcode_manager`
# --------------------------------------------------------



#
# Delete any existing table `wp_usermeta`
#

DROP TABLE IF EXISTS `wp_usermeta`;


#
# Table structure of table `wp_usermeta`
#

CREATE TABLE `wp_usermeta` (
  `umeta_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`umeta_id`),
  KEY `user_id` (`user_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=84 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_usermeta`
#
INSERT INTO `wp_usermeta` ( `umeta_id`, `user_id`, `meta_key`, `meta_value`) VALUES
(1, 1, 'nickname', 'admin'),
(2, 1, 'first_name', ''),
(3, 1, 'last_name', ''),
(4, 1, 'description', ''),
(5, 1, 'rich_editing', 'true'),
(6, 1, 'syntax_highlighting', 'true'),
(7, 1, 'comment_shortcuts', 'false'),
(8, 1, 'admin_color', 'fresh'),
(9, 1, 'use_ssl', '0'),
(10, 1, 'show_admin_bar_front', 'true'),
(11, 1, 'locale', ''),
(12, 1, 'wp_capabilities', 'a:1:{s:13:"administrator";b:1;}'),
(13, 1, 'wp_user_level', '10'),
(14, 1, 'dismissed_wp_pointers', ''),
(15, 1, 'show_welcome_panel', '0'),
(16, 1, 'session_tokens', 'a:1:{s:64:"4f54a1ce0544f9e09db959bcfb3319b4a1c00b3723fbeab06e0618c188cd8dcb";a:4:{s:10:"expiration";i:1664132450;s:2:"ip";s:9:"127.0.0.1";s:2:"ua";s:117:"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/105.0.0.0 Safari/537.36";s:5:"login";i:1662922850;}}'),
(17, 1, 'wp_dashboard_quick_press_last_post_id', '658'),
(18, 2, 'nickname', 'jeff.barnett@nowrx.com'),
(19, 2, 'first_name', ''),
(20, 2, 'last_name', ''),
(21, 2, 'description', ''),
(22, 2, 'rich_editing', 'true'),
(23, 2, 'syntax_highlighting', 'true'),
(24, 2, 'comment_shortcuts', 'false'),
(25, 2, 'admin_color', 'fresh'),
(26, 2, 'use_ssl', '0'),
(27, 2, 'show_admin_bar_front', 'true'),
(28, 2, 'locale', ''),
(29, 2, 'wp_capabilities', 'a:1:{s:10:"subscriber";b:1;}'),
(30, 2, 'wp_user_level', '0'),
(31, 2, 'dismissed_wp_pointers', ''),
(32, 3, 'nickname', 'NowRx Pharmacy'),
(33, 3, 'first_name', 'NowRx'),
(34, 3, 'last_name', 'Pharmacy'),
(35, 3, 'description', ''),
(36, 3, 'rich_editing', 'true'),
(37, 3, 'syntax_highlighting', 'true'),
(38, 3, 'comment_shortcuts', 'false'),
(39, 3, 'admin_color', 'fresh'),
(40, 3, 'use_ssl', '0'),
(41, 3, 'show_admin_bar_front', 'true'),
(42, 3, 'locale', ''),
(43, 3, 'wp_capabilities', 'a:1:{s:10:"subscriber";b:1;}'),
(44, 3, 'wp_user_level', '0'),
(45, 3, 'dismissed_wp_pointers', ''),
(46, 4, 'nickname', 'Jose'),
(47, 4, 'first_name', 'Jose'),
(48, 4, 'last_name', 'Mendoza'),
(49, 4, 'description', ''),
(50, 4, 'rich_editing', 'true'),
(51, 4, 'syntax_highlighting', 'true'),
(52, 4, 'comment_shortcuts', 'false'),
(53, 4, 'admin_color', 'fresh'),
(54, 4, 'use_ssl', '0'),
(55, 4, 'show_admin_bar_front', 'true'),
(56, 4, 'locale', ''),
(57, 4, 'wp_capabilities', 'a:1:{s:10:"subscriber";b:1;}'),
(58, 4, 'wp_user_level', '0'),
(59, 4, 'dismissed_wp_pointers', ''),
(60, 5, 'nickname', 'Phil'),
(61, 5, 'first_name', 'Phil'),
(62, 5, 'last_name', 'Rossi'),
(63, 5, 'description', ''),
(64, 5, 'rich_editing', 'true'),
(65, 5, 'syntax_highlighting', 'true'),
(66, 5, 'comment_shortcuts', 'false'),
(67, 5, 'admin_color', 'fresh'),
(68, 5, 'use_ssl', '0'),
(69, 5, 'show_admin_bar_front', 'true'),
(70, 5, 'locale', ''),
(71, 5, 'wp_capabilities', 'a:1:{s:10:"subscriber";b:1;}'),
(72, 5, 'wp_user_level', '0'),
(73, 5, 'dismissed_wp_pointers', ''),
(74, 1, 'AkeebaSession_id', 'fd5122fa1a4faec45d149da24d43206b'),
(75, 1, 'wp_yoast_notifications', 'a:1:{i:0;a:2:{s:7:"message";s:369:"<strong>New in Yoast SEO 14.9: </strong>We now have Hebrew keyphrase recognition and some great performance improvements! <a href="https://yoa.st/yoast14-9?php_version=7.4&#038;platform=wordpress&#038;platform_version=5.5.1&#038;software=free&#038;software_version=14.9&#038;days_active=0-1&#038;user_language=en_US" target="_blank">Read all about version 14.9 here</a>";s:7:"options";a:10:{s:4:"type";s:7:"updated";s:2:"id";s:20:"wpseo-plugin-updated";s:4:"user";O:7:"WP_User":8:{s:4:"data";O:8:"stdClass":10:{s:2:"ID";s:1:"1";s:10:"user_login";s:5:"admin";s:9:"user_pass";s:34:"$P$BDYVeBINCom4MytQokSIcRQ6y3nni..";s:13:"user_nicename";s:5:"admin";s:10:"user_email";s:22:"jeff.barnett@nowrx.com";s:8:"user_url";s:26:"http://localhost:8888/dev2";s:15:"user_registered";s:19:"2020-09-21 21:03:25";s:19:"user_activation_key";s:0:"";s:11:"user_status";s:1:"0";s:12:"display_name";s:5:"admin";}s:2:"ID";i:1;s:4:"caps";a:1:{s:13:"administrator";b:1;}s:7:"cap_key";s:15:"wp_capabilities";s:5:"roles";a:1:{i:0;s:13:"administrator";}s:7:"allcaps";a:63:{s:13:"switch_themes";b:1;s:11:"edit_themes";b:1;s:16:"activate_plugins";b:1;s:12:"edit_plugins";b:1;s:10:"edit_users";b:1;s:10:"edit_files";b:1;s:14:"manage_options";b:1;s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:6:"import";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:8:"level_10";b:1;s:7:"level_9";b:1;s:7:"level_8";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;s:12:"delete_users";b:1;s:12:"create_users";b:1;s:17:"unfiltered_upload";b:1;s:14:"edit_dashboard";b:1;s:14:"update_plugins";b:1;s:14:"delete_plugins";b:1;s:15:"install_plugins";b:1;s:13:"update_themes";b:1;s:14:"install_themes";b:1;s:11:"update_core";b:1;s:10:"list_users";b:1;s:12:"remove_users";b:1;s:13:"promote_users";b:1;s:18:"edit_theme_options";b:1;s:13:"delete_themes";b:1;s:6:"export";b:1;s:20:"wpseo_manage_options";b:1;s:13:"administrator";b:1;}s:6:"filter";N;s:16:"\0WP_User\0site_id";i:1;}s:5:"nonce";N;s:8:"priority";d:0.5;s:9:"data_json";a:1:{s:13:"dismiss_value";s:4:"14.9";}s:13:"dismissal_key";s:20:"wpseo-plugin-updated";s:12:"capabilities";a:1:{i:0;s:20:"wpseo_manage_options";}s:16:"capability_check";s:3:"all";s:14:"yoast_branding";b:0;}}}'),
(78, 1, 'leadin_email', 'jeff.barnett@nowrx.com'),
(79, 1, '_yoast_wpseo_profile_updated', '1600727268'),
(80, 2, 'session_tokens', 'a:1:{s:64:"77352f0b0a17c2700457c38572e1beb2e1c4b73634ed379bc185c99a6677c1a0";a:4:{s:10:"expiration";i:1603299396;s:2:"ip";s:3:"::1";s:2:"ua";s:120:"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.80 Safari/537.36";s:5:"login";i:1603126596;}}'),
(81, 1, 'wp_user-settings', 'posts_list_mode=list'),
(82, 1, 'wp_user-settings-time', '1662922848'),
(83, 1, 'community-events-location', 'a:1:{s:2:"ip";s:9:"127.0.0.0";}') ;

#
# End of data contents of table `wp_usermeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_users`
#

DROP TABLE IF EXISTS `wp_users`;


#
# Table structure of table `wp_users`
#

CREATE TABLE `wp_users` (
  `ID` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_login` varchar(60) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_pass` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_nicename` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_email` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_url` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_activation_key` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_status` int NOT NULL DEFAULT '0',
  `display_name` varchar(250) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`ID`),
  KEY `user_login_key` (`user_login`),
  KEY `user_nicename` (`user_nicename`),
  KEY `user_email` (`user_email`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_users`
#
INSERT INTO `wp_users` ( `ID`, `user_login`, `user_pass`, `user_nicename`, `user_email`, `user_url`, `user_registered`, `user_activation_key`, `user_status`, `display_name`) VALUES
(1, 'admin', '$P$BDJmhmSCpTkD2PvcIESTz32/cBIQcv.', 'admin', 'jeff.barnett@nowrx.com', 'http://localhost:8888/dev2', '2020-09-21 21:03:25', '', 0, 'admin'),
(2, 'jeff', '$P$BszQWRbz3z9w7v9TJRBgCSEl5n3T0H0', 'jeff-barnettnowrx-com', 'jeff.barnett@nowrx.com', '', '2020-09-21 21:07:12', '', 0, 'jeff.barnett@nowrx.com'),
(3, 'NowRx Pharmacy', '$P$BK7X7QaAFrp63umkkPDgupsROZKaDv.', 'nowrx-pharmacy', 'info@nowrx.com', '', '2020-09-21 21:07:27', '', 0, 'NowRx Pharmacy'),
(4, 'Jose', '$P$BS/sxkgo2P.288BxRzRlzQYJMDOhjE/', 'jose', 'jose@uituners.com', '', '2020-09-21 21:07:27', '', 0, 'Jose Mendoza'),
(5, 'Phil', '$P$B04WIBDjbm5r9R/7P/RDOqtZMhatcA.', 'phil', 'phillip.rossi@nowrx.com', '', '2020-09-21 21:07:27', '', 0, 'Phil Rossi') ;

#
# End of data contents of table `wp_users`
# --------------------------------------------------------



#
# Delete any existing table `wp_yoast_indexable`
#

DROP TABLE IF EXISTS `wp_yoast_indexable`;


#
# Table structure of table `wp_yoast_indexable`
#

CREATE TABLE `wp_yoast_indexable` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `permalink` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci,
  `permalink_hash` varchar(40) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `object_id` int unsigned DEFAULT NULL,
  `object_type` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `object_sub_type` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `author_id` int unsigned DEFAULT NULL,
  `post_parent` int unsigned DEFAULT NULL,
  `title` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci,
  `description` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci,
  `breadcrumb_title` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci,
  `post_status` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `is_public` tinyint(1) DEFAULT NULL,
  `is_protected` tinyint(1) DEFAULT '0',
  `has_public_posts` tinyint(1) DEFAULT NULL,
  `number_of_pages` int unsigned DEFAULT NULL,
  `canonical` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci,
  `primary_focus_keyword` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `primary_focus_keyword_score` int DEFAULT NULL,
  `readability_score` int DEFAULT NULL,
  `is_cornerstone` tinyint(1) DEFAULT '0',
  `is_robots_noindex` tinyint(1) DEFAULT '0',
  `is_robots_nofollow` tinyint(1) DEFAULT '0',
  `is_robots_noarchive` tinyint(1) DEFAULT '0',
  `is_robots_noimageindex` tinyint(1) DEFAULT '0',
  `is_robots_nosnippet` tinyint(1) DEFAULT '0',
  `twitter_title` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci,
  `twitter_image` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci,
  `twitter_description` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci,
  `twitter_image_id` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `twitter_image_source` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci,
  `open_graph_title` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci,
  `open_graph_description` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci,
  `open_graph_image` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci,
  `open_graph_image_id` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `open_graph_image_source` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci,
  `open_graph_image_meta` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci,
  `link_count` int DEFAULT NULL,
  `incoming_link_count` int DEFAULT NULL,
  `prominent_words_version` int unsigned DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `blog_id` bigint NOT NULL DEFAULT '1',
  `language` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `region` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `schema_page_type` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `schema_article_type` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `has_ancestors` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `object_type_and_sub_type` (`object_type`,`object_sub_type`),
  KEY `object_id_and_type` (`object_id`,`object_type`),
  KEY `permalink_hash_and_object_type` (`permalink_hash`,`object_type`),
  KEY `subpages` (`post_parent`,`object_type`,`post_status`,`object_id`),
  KEY `prominent_words` (`prominent_words_version`,`object_type`,`object_sub_type`,`post_status`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_yoast_indexable`
#
INSERT INTO `wp_yoast_indexable` ( `id`, `permalink`, `permalink_hash`, `object_id`, `object_type`, `object_sub_type`, `author_id`, `post_parent`, `title`, `description`, `breadcrumb_title`, `post_status`, `is_public`, `is_protected`, `has_public_posts`, `number_of_pages`, `canonical`, `primary_focus_keyword`, `primary_focus_keyword_score`, `readability_score`, `is_cornerstone`, `is_robots_noindex`, `is_robots_nofollow`, `is_robots_noarchive`, `is_robots_noimageindex`, `is_robots_nosnippet`, `twitter_title`, `twitter_image`, `twitter_description`, `twitter_image_id`, `twitter_image_source`, `open_graph_title`, `open_graph_description`, `open_graph_image`, `open_graph_image_id`, `open_graph_image_source`, `open_graph_image_meta`, `link_count`, `incoming_link_count`, `prominent_words_version`, `created_at`, `updated_at`, `blog_id`, `language`, `region`, `schema_page_type`, `schema_article_type`, `has_ancestors`) VALUES
(1, 'http://localhost:8888/dev2/author/admin/', '40:def4c6b55106ca444121cf499c905330', 1, 'user', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, NULL, 'https://2.gravatar.com/avatar/28a34b472f2df04fbc383020dd6812ad?s=500&d=mm&r=g', NULL, NULL, 'gravatar-image', NULL, NULL, 'https://2.gravatar.com/avatar/28a34b472f2df04fbc383020dd6812ad?s=500&d=mm&r=g', NULL, 'gravatar-image', NULL, NULL, NULL, NULL, '2020-09-21 21:12:19', '2020-09-21 23:29:07', 1, NULL, NULL, NULL, NULL, 0),
(2, 'http://localhost:8888/dev2/2020/09/21/hello-world/', '50:bb11e7e4eed04ee10cc71da7e8a27a30', 1, 'post', 'post', 1, 0, NULL, NULL, 'Hello world!', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2020-09-21 21:12:19', '2020-09-21 21:12:19', 1, NULL, NULL, NULL, NULL, 0),
(3, 'http://localhost:8888/dev2/author/jeff-barnettnowrx-com/', '56:b9fc581f6ea98dd4f989742b417e3331', 2, 'user', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, NULL, 'https://2.gravatar.com/avatar/28a34b472f2df04fbc383020dd6812ad?s=500&d=mm&r=g', NULL, NULL, 'gravatar-image', NULL, NULL, 'https://2.gravatar.com/avatar/28a34b472f2df04fbc383020dd6812ad?s=500&d=mm&r=g', NULL, 'gravatar-image', NULL, NULL, NULL, NULL, '2020-09-21 21:12:19', '2020-09-21 21:12:19', 1, NULL, NULL, NULL, NULL, 0),
(4, 'http://localhost:8888/dev2/2020/09/01/hello-world-2/', '52:e2dea6ba7cd2d8e79201b1ee80c3457b', 6, 'post', 'post', 2, 0, NULL, NULL, 'Hello world!', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2020-09-21 21:12:19', '2020-09-21 21:12:19', 1, NULL, NULL, NULL, NULL, 0),
(5, 'http://localhost:8888/dev2/', '27:c89f2bfe75a42b5c956eb55cdf762ae1', NULL, 'home-page', NULL, NULL, NULL, '%%sitename%% %%page%% %%sep%% %%sitedesc%%', 'Just another WordPress site', 'Home', NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, '', '', '', '', NULL, NULL, NULL, NULL, NULL, '2020-09-21 21:14:01', '2020-09-21 21:14:01', 1, NULL, NULL, NULL, NULL, 0),
(6, 'http://localhost:8888/dev2/author/jose/', '39:85bb73934434127a79778057d8c726b8', 4, 'user', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, NULL, 'https://0.gravatar.com/avatar/cf79e57683f947e8eed034159e82487a?s=500&d=mm&r=g', NULL, NULL, 'gravatar-image', NULL, NULL, 'https://0.gravatar.com/avatar/cf79e57683f947e8eed034159e82487a?s=500&d=mm&r=g', NULL, 'gravatar-image', NULL, NULL, NULL, NULL, '2020-09-21 23:05:14', '2020-09-21 23:05:14', 1, NULL, NULL, NULL, NULL, 0),
(7, 'http://localhost:8888/dev2/', '27:c89f2bfe75a42b5c956eb55cdf762ae1', 30, 'post', 'page', 4, 0, 'Prescription Delivery in Hours for Free | NowRx ®', 'Prescription delivery right to your door. We deliver all medication including controlled and over the counter. No delivery fees - Get started in minutes!', 'Home', 'publish', NULL, 0, NULL, NULL, NULL, 'pharmacy delivery', 25, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2020-09-21 23:05:14', '2020-09-21 23:05:14', 1, NULL, NULL, NULL, NULL, 0),
(8, 'http://localhost:8888/dev2/wp-content/uploads/2020/09/logo.svg', '62:b594adc8d8bf2d0b5ae0a262624deef2', 655, 'post', 'attachment', 1, 0, NULL, NULL, 'logo', 'inherit', 0, 0, 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2020-09-21 23:20:19', '2020-09-21 23:20:19', 1, NULL, NULL, NULL, NULL, 0),
(9, 'http://localhost:8888/dev2/wp-content/uploads/2020/09/hero-home.jpg', '67:79f24676dd3d2029416acb5dffa4ac54', 656, 'post', 'attachment', 1, 0, NULL, NULL, 'hero-home', 'inherit', 0, 0, 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, 'http://localhost:8888/dev2/wp-content/uploads/2020/09/hero-home.jpg', NULL, '656', 'attachment-image', NULL, NULL, NULL, '656', 'attachment-image', NULL, 0, NULL, NULL, '2020-09-21 23:29:07', '2020-09-21 23:29:07', 1, NULL, NULL, NULL, NULL, 0),
(10, NULL, NULL, NULL, 'system-page', '404', NULL, NULL, 'Page not found %%sep%% %%sitename%%', NULL, 'Error 404: Page not found', NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, 1, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-09-21 23:30:48', '2020-09-21 23:30:48', 1, NULL, NULL, NULL, NULL, 0) ;

#
# End of data contents of table `wp_yoast_indexable`
# --------------------------------------------------------



#
# Delete any existing table `wp_yoast_indexable_hierarchy`
#

DROP TABLE IF EXISTS `wp_yoast_indexable_hierarchy`;


#
# Table structure of table `wp_yoast_indexable_hierarchy`
#

CREATE TABLE `wp_yoast_indexable_hierarchy` (
  `indexable_id` int unsigned NOT NULL,
  `ancestor_id` int unsigned NOT NULL,
  `depth` int unsigned DEFAULT NULL,
  `blog_id` bigint NOT NULL DEFAULT '1',
  PRIMARY KEY (`indexable_id`,`ancestor_id`),
  KEY `indexable_id` (`indexable_id`),
  KEY `ancestor_id` (`ancestor_id`),
  KEY `depth` (`depth`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_yoast_indexable_hierarchy`
#

#
# End of data contents of table `wp_yoast_indexable_hierarchy`
# --------------------------------------------------------



#
# Delete any existing table `wp_yoast_migrations`
#

DROP TABLE IF EXISTS `wp_yoast_migrations`;


#
# Table structure of table `wp_yoast_migrations`
#

CREATE TABLE `wp_yoast_migrations` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `version` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `wp_yoast_migrations_version` (`version`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_yoast_migrations`
#
INSERT INTO `wp_yoast_migrations` ( `id`, `version`) VALUES
(1, '20171228151840'),
(2, '20171228151841'),
(3, '20190529075038'),
(4, '20191011111109'),
(5, '20200408101900'),
(6, '20200420073606'),
(7, '20200428123747'),
(8, '20200428194858'),
(9, '20200429105310'),
(10, '20200430075614'),
(11, '20200430150130'),
(12, '20200507054848'),
(13, '20200513133401'),
(14, '20200609154515'),
(15, '20200616130143'),
(16, '20200617122511'),
(17, '20200702141921'),
(18, '20200728095334') ;

#
# End of data contents of table `wp_yoast_migrations`
# --------------------------------------------------------



#
# Delete any existing table `wp_yoast_primary_term`
#

DROP TABLE IF EXISTS `wp_yoast_primary_term`;


#
# Table structure of table `wp_yoast_primary_term`
#

CREATE TABLE `wp_yoast_primary_term` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `post_id` int unsigned NOT NULL,
  `term_id` int unsigned NOT NULL,
  `taxonomy` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `blog_id` bigint NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `post_taxonomy` (`post_id`,`taxonomy`),
  KEY `post_term` (`post_id`,`term_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_yoast_primary_term`
#

#
# End of data contents of table `wp_yoast_primary_term`
# --------------------------------------------------------



#
# Delete any existing table `wp_yoast_seo_links`
#

DROP TABLE IF EXISTS `wp_yoast_seo_links`;


#
# Table structure of table `wp_yoast_seo_links`
#

CREATE TABLE `wp_yoast_seo_links` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `url` varchar(255) DEFAULT NULL,
  `post_id` bigint unsigned DEFAULT NULL,
  `target_post_id` bigint unsigned DEFAULT NULL,
  `type` varchar(8) DEFAULT NULL,
  `indexable_id` int unsigned DEFAULT NULL,
  `target_indexable_id` int unsigned DEFAULT NULL,
  `height` int unsigned DEFAULT NULL,
  `width` int unsigned DEFAULT NULL,
  `size` int unsigned DEFAULT NULL,
  `language` varchar(32) DEFAULT NULL,
  `region` varchar(32) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `link_direction` (`post_id`,`type`),
  KEY `indexable_link_direction` (`indexable_id`,`type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;


#
# Data contents of table `wp_yoast_seo_links`
#

#
# End of data contents of table `wp_yoast_seo_links`
# --------------------------------------------------------

#
# Add constraints back in and apply any alter data queries.
#

